package com.tickethub.system;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.exception.AuthenticationException;
import com.tickethub.exception.NotFoundException;
import com.tickethub.exception.TicketHubException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.Booking;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.PromoCode;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.support.Fixture;
import java.math.BigDecimal;
import java.time.Duration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** System test: robustness - the system must fail in a controlled way for abnormal input and state. */
class RobustnessSystemTest {
    private Fixture f;
    private User user;
    private Event event;

    @BeforeEach
    void setUp() {
        f = new Fixture();
        user = f.newUser();
        event = f.standardEvent();
    }

    @Test
    @DisplayName("TC-SYS-ROB-01 | SYS-ROB | Null arguments to every public service -> only controlled TicketHubException, never NullPointerException")
    void nullArguments() {
        assertThrows(TicketHubException.class, () -> f.hub.users.register(null, null, null));
        assertThrows(TicketHubException.class, () -> f.hub.users.login(null, null));
        assertThrows(TicketHubException.class, () -> f.hub.events.createEvent(null, null, null, 0, null));
        assertThrows(TicketHubException.class, () -> f.hub.pricing.calculateTotal(null, null, 0, null));
        assertThrows(TicketHubException.class, () -> f.hub.payments.process(null, null, null, null));
        assertThrows(TicketHubException.class, () -> f.hub.bookings.book(user.getId(), event.getId(), null, 1, null, null, null));
        assertEquals(1, f.hub.events.search(null).size());
    }

    @Test
    @DisplayName("TC-SYS-ROB-02 | SYS-ROB | 1,000,000-character name and email -> rejected quickly with ValidationException")
    void hugeStrings() {
        String huge = "A".repeat(1_000_000);
        assertThrows(ValidationException.class, () -> f.hub.users.register(huge, "a@example.com", "Passw0rd1"));
        assertThrows(ValidationException.class, () -> f.hub.users.register("Alice", huge + "@example.com", "Passw0rd1"));
        assertThrows(ValidationException.class, () -> f.hub.users.register("Alice", "b@example.com", huge));
    }

    @Test
    @DisplayName("TC-SYS-ROB-03 | SYS-ROB | Integer extremes (MIN_VALUE, MAX_VALUE, -1) for quantity and capacity -> ValidationException, no overflow")
    void integerExtremes() {
        for (int q : new int[] {Integer.MIN_VALUE, -1, Integer.MAX_VALUE}) {
            assertThrows(ValidationException.class, () -> f.hub.bookings.book(user.getId(), event.getId(),
                    TicketType.STANDARD, q, "", PaymentMethod.WALLET, null));
            assertThrows(ValidationException.class, () -> f.hub.events.createEvent("Show", "Hall",
                    f.now().plusDays(1), q, new BigDecimal("10")));
        }
        assertEquals(1000, event.getAvailable());
    }

    @Test
    @DisplayName("TC-SYS-ROB-04 | SYS-ROB | Control characters and NUL byte inside a name -> handled without crash, stored verbatim")
    void controlCharacters() {
        User u = assertDoesNotThrow(() -> f.hub.users.register("A\u0000B\t\n", "ctl@example.com", "Passw0rd1"));
        assertEquals("A\u0000B", u.getName());
    }

    @Test
    @DisplayName("TC-SYS-ROB-05 | SYS-ROB | Out-of-range ids (-1, 0, Integer.MAX_VALUE) for user, event and booking -> NotFoundException")
    void outOfRangeIds() {
        for (int id : new int[] {-1, 0, Integer.MAX_VALUE}) {
            assertThrows(NotFoundException.class, () -> f.hub.users.findById(id));
            assertThrows(NotFoundException.class, () -> f.hub.events.findById(id));
            assertThrows(NotFoundException.class, () -> f.hub.bookings.findById(id));
        }
    }

    @Test
    @DisplayName("TC-SYS-ROB-06 | SYS-ROB | Illegal state sequences (cancel twice, rebook after cancel) -> controlled errors and consistent seats")
    void illegalStateSequences() {
        Booking b = f.hub.bookings.book(user.getId(), event.getId(), TicketType.STANDARD, 10, "", PaymentMethod.WALLET, null);
        f.hub.bookings.cancel(user.getId(), b.getId());
        assertThrows(TicketHubException.class, () -> f.hub.bookings.cancel(user.getId(), b.getId()));
        Booking again = f.hub.bookings.book(user.getId(), event.getId(), TicketType.STANDARD, 10, "", PaymentMethod.WALLET, null);
        assertEquals(990, event.getAvailable());
        assertTrue(again.getId() != b.getId());
    }

    @Test
    @DisplayName("TC-SYS-ROB-07 | SYS-ROB | 200 further login attempts on a locked account -> always 'Account locked', no other failure")
    void lockedAccountHammering() {
        for (int i = 0; i < 3; i++) {
            assertThrows(AuthenticationException.class, () -> f.hub.users.login(user.getEmail(), "wrong"));
        }
        for (int i = 0; i < 200; i++) {
            AuthenticationException e = assertThrows(AuthenticationException.class,
                    () -> f.hub.users.login(user.getEmail(), Fixture.PASSWORD));
            assertEquals("Account locked", e.getMessage());
        }
    }

    @Test
    @DisplayName("TC-SYS-ROB-08 | SYS-ROB | Search keywords made of regex/wildcard characters ('.*', '(', '[', '\\\\') -> no exception, no false matches")
    void regexMetacharactersInSearch() {
        for (String k : new String[] {".*", "(", "[", "\\", "%", "' OR '1'='1"}) {
            assertEquals(0, assertDoesNotThrow(() -> f.hub.events.search(k)).size());
        }
    }

    @Test
    @DisplayName("TC-SYS-ROB-09 | SYS-ROB | Negative payment amount and unknown promo during booking -> rejected, seats and wallet untouched")
    void negativeAmountAndBadPromo() {
        assertThrows(ValidationException.class,
                () -> f.hub.payments.process(user, PaymentMethod.WALLET, null, new BigDecimal("-1.00")));
        assertThrows(ValidationException.class, () -> f.hub.bookings.book(user.getId(), event.getId(),
                TicketType.VIP, 1, "'; DROP--", PaymentMethod.WALLET, null));
        assertEquals("5000.00", user.getWalletBalance().toPlainString());
        assertEquals(1000, event.getAvailable());
        assertEquals(PromoCode.NONE, PromoCode.parse("   "));
    }

    @Test
    @DisplayName("TC-SYS-ROB-10 | SYS-ROB | Event created for 10 days ahead then clock jumps 11 days -> booking refused, search empty")
    void clockJump() {
        f.clock.advance(Duration.ofDays(11));
        assertThrows(TicketHubException.class, () -> f.hub.bookings.book(user.getId(), event.getId(),
                TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null));
        assertTrue(f.hub.events.search("").isEmpty());
    }
}
