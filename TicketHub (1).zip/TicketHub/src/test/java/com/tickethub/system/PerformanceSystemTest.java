package com.tickethub.system;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.PromoCode;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.service.PricingService;
import com.tickethub.support.Fixture;
import com.tickethub.support.PerfLog;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** System test: performance - response-time budgets for the main operations (generous limits, run on a laptop). */
class PerformanceSystemTest {

    @Test
    @DisplayName("TC-SYS-PERF-01 | SYS-PERF | 100,000 price calculations complete within 2000 ms")
    void pricingThroughput() {
        PricingService pricing = new PricingService();
        BigDecimal base = new BigDecimal("123.45");
        long start = System.nanoTime();
        BigDecimal last = null;
        for (int i = 0; i < 100_000; i++) {
            last = pricing.calculateTotal(base, TicketType.values()[i % 3], 1 + i % 10, PromoCode.values()[i % 3]);
        }
        long ms = (System.nanoTime() - start) / 1_000_000;
        PerfLog.record("TC-SYS-PERF-01", "100,000 price calculations", ms + " ms (limit 2000 ms)");
        assertTrue(last != null && ms < 2000, "took " + ms + " ms");
    }

    @Test
    @DisplayName("TC-SYS-PERF-02 | SYS-PERF | 100 keyword searches over 10,000 events complete within 3000 ms")
    void searchLatency() {
        Fixture f = new Fixture();
        for (int i = 0; i < 10_000; i++) {
            f.hub.events.createEvent("Event " + i, "Venue " + (i % 50), f.now().plusDays(1 + i % 300), 100, new BigDecimal("25.00"));
        }
        long start = System.nanoTime();
        int found = 0;
        for (int i = 0; i < 100; i++) {
            found += f.hub.events.search("venue " + (i % 50)).size();
        }
        long ms = (System.nanoTime() - start) / 1_000_000;
        PerfLog.record("TC-SYS-PERF-02", "100 searches over 10,000 events", ms + " ms (limit 3000 ms)");
        assertTrue(found > 0);
        assertTrue(ms < 3000, "took " + ms + " ms");
    }

    @Test
    @DisplayName("TC-SYS-PERF-03 | SYS-PERF | 1,000 sequential wallet bookings complete within 3000 ms")
    void bookingThroughput() {
        Fixture f = new Fixture();
        Event e = f.event(Duration.ofDays(30), 10_000, "10.00");
        List<User> people = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            people.add(f.newUser());
        }
        long start = System.nanoTime();
        for (User u : people) {
            f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 2, "", PaymentMethod.WALLET, null);
        }
        long ms = (System.nanoTime() - start) / 1_000_000;
        PerfLog.record("TC-SYS-PERF-03", "1,000 sequential bookings", ms + " ms (limit 3000 ms)");
        assertEquals(10_000 - 2000, e.getAvailable());
        assertTrue(ms < 3000, "took " + ms + " ms");
    }

    @Test
    @DisplayName("TC-SYS-PERF-04 | SYS-PERF | 2,000 registrations followed by 2,000 logins complete within 5000 ms")
    void registrationAndLogin() {
        Fixture f = new Fixture();
        long start = System.nanoTime();
        for (int i = 0; i < 2000; i++) {
            f.hub.users.register("User " + i, "perf" + i + "@example.com", Fixture.PASSWORD);
        }
        for (int i = 0; i < 2000; i++) {
            f.hub.users.login("perf" + i + "@example.com", Fixture.PASSWORD);
        }
        long ms = (System.nanoTime() - start) / 1_000_000;
        PerfLog.record("TC-SYS-PERF-04", "2,000 registrations + 2,000 logins", ms + " ms (limit 5000 ms)");
        assertEquals(2000, f.hub.users.count());
        assertTrue(ms < 5000, "took " + ms + " ms");
    }
}
