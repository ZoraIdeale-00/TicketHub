package com.tickethub.system;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.exception.BusinessRuleException;
import com.tickethub.exception.PaymentException;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.support.Fixture;
import com.tickethub.support.PerfLog;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** System test: scalability - behaviour under concurrent load and growing data volume. */
class ScalabilitySystemTest {

    /** Runs all tasks at the same instant on separate threads and waits for completion. */
    private static void runConcurrently(List<Runnable> tasks) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(tasks.size());
        CountDownLatch ready = new CountDownLatch(tasks.size());
        CountDownLatch go = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(tasks.size());
        for (Runnable t : tasks) {
            pool.submit(() -> {
                ready.countDown();
                try {
                    go.await();
                    t.run();
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                } finally {
                    done.countDown();
                }
            });
        }
        ready.await();
        go.countDown();
        assertTrue(done.await(60, TimeUnit.SECONDS), "tasks did not finish in time");
        pool.shutdown();
    }

    @Test
    @DisplayName("TC-SYS-SCAL-01 | SYS-SCAL | 200 users book the last 100 seats at the same instant -> exactly 100 succeed, no overselling")
    void noOverselling() throws Exception {
        Fixture f = new Fixture();
        Event e = f.event(Duration.ofDays(5), 100, "20.00");
        AtomicInteger ok = new AtomicInteger();
        AtomicInteger soldOut = new AtomicInteger();
        List<Runnable> tasks = new ArrayList<>();
        for (int i = 0; i < 200; i++) {
            User u = f.newUser();
            tasks.add(() -> {
                try {
                    f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null);
                    ok.incrementAndGet();
                } catch (BusinessRuleException ex) {
                    soldOut.incrementAndGet();
                }
            });
        }
        runConcurrently(tasks);
        PerfLog.record("TC-SYS-SCAL-01", "200 concurrent bookings for 100 seats", ok + " succeeded, " + soldOut + " refused");
        assertEquals(100, ok.get());
        assertEquals(100, soldOut.get());
        assertEquals(0, e.getAvailable());
    }

    @Test
    @DisplayName("TC-SYS-SCAL-02 | SYS-SCAL | 50 simultaneous registrations with the same email -> exactly one account created")
    void duplicateRegistrationRace() throws Exception {
        Fixture f = new Fixture();
        AtomicInteger ok = new AtomicInteger();
        List<Runnable> tasks = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            tasks.add(() -> {
                try {
                    f.hub.users.register("Racer", "race@example.com", Fixture.PASSWORD);
                    ok.incrementAndGet();
                } catch (BusinessRuleException ignored) {
                    // duplicate - expected for 49 of them
                }
            });
        }
        runConcurrently(tasks);
        assertEquals(1, ok.get());
        assertEquals(1, f.hub.users.count());
    }

    @Test
    @DisplayName("TC-SYS-SCAL-03 | SYS-SCAL | 100 simultaneous wallet payments from one user (105.00 each, balance 5000.00) -> exactly 47 succeed, balance 65.00, seats consistent")
    void walletRace() throws Exception {
        Fixture f = new Fixture();
        User u = f.newUser();
        Event e = f.standardEvent();
        AtomicInteger ok = new AtomicInteger();
        AtomicInteger declined = new AtomicInteger();
        List<Runnable> tasks = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            tasks.add(() -> {
                try {
                    f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null);
                    ok.incrementAndGet();
                } catch (PaymentException ex) {
                    declined.incrementAndGet();
                }
            });
        }
        runConcurrently(tasks);
        assertEquals(47, ok.get());
        assertEquals(53, declined.get());
        assertEquals(new BigDecimal("65.00"), u.getWalletBalance());
        assertEquals(1000 - 47, e.getAvailable());
    }

    @Test
    @DisplayName("TC-SYS-SCAL-04 | SYS-SCAL | Search cost grows roughly linearly with data volume: 1,000 / 10,000 / 50,000 events (20 searches each), 50k within 5000 ms")
    void searchGrowth() {
        int[] sizes = {1_000, 10_000, 50_000};
        long[] nanos = new long[sizes.length];
        for (int s = 0; s < sizes.length; s++) {
            Fixture f = new Fixture();
            for (int i = 0; i < sizes[s]; i++) {
                f.hub.events.createEvent("Show " + i, "Hall " + (i % 20), f.now().plusDays(1 + i % 365), 50, BigDecimal.TEN);
            }
            long start = System.nanoTime();
            for (int i = 0; i < 20; i++) {
                f.hub.events.search("hall " + (i % 20));
            }
            nanos[s] = System.nanoTime() - start;
            PerfLog.record("TC-SYS-SCAL-04", "20 searches over " + sizes[s] + " events", nanos[s] / 1_000_000 + " ms");
        }
        double ratio = (double) nanos[2] / Math.max(1L, nanos[0]);
        PerfLog.record("TC-SYS-SCAL-04", "time(50,000) / time(1,000) for 50x data", String.format(java.util.Locale.ROOT, "%.1fx", ratio));
        assertTrue(nanos[2] / 1_000_000 < 5000, "50k events took " + nanos[2] / 1_000_000 + " ms");
        assertTrue(ratio < 500, "growth looks worse than linear: " + ratio + "x");
    }
}
