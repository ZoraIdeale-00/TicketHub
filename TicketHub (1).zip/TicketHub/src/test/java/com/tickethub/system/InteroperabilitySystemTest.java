package com.tickethub.system;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.exception.AuthenticationException;
import com.tickethub.exception.BusinessRuleException;
import com.tickethub.exception.TicketHubException;
import com.tickethub.model.Booking;
import com.tickethub.model.BookingStatus;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.support.Fixture;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.ZoneId;
import java.util.Locale;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** System test: interoperability - locales, time zones, character sets and cooperation between components. */
class InteroperabilitySystemTest {

    @Test
    @DisplayName("TC-SYS-INT-01 | SYS-INT | Under default locales de-DE, fr-FR, ar-EG and th-TH, totals and receipts still use '.' decimals")
    void localeIndependence() {
        Locale original = Locale.getDefault();
        try {
            for (Locale l : new Locale[] {Locale.GERMANY, Locale.FRANCE, Locale.forLanguageTag("ar-EG"), Locale.forLanguageTag("th-TH")}) {
                Locale.setDefault(l);
                Fixture f = new Fixture();
                User u = f.newUser();
                Event e = f.standardEvent();
                Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.VIP, 1, "SAVE10", PaymentMethod.WALLET, null);
                assertEquals("189.00", b.getTotal().toPlainString());
                assertTrue(b.summary().contains("total 189.00"), b.summary());
            }
        } finally {
            Locale.setDefault(original);
        }
    }

    @Test
    @DisplayName("TC-SYS-INT-02 | SYS-INT | Cancellation windows behave identically in UTC, Asia/Kuala_Lumpur, America/New_York and Pacific/Auckland")
    void timeZoneIndependence() {
        for (String zone : new String[] {"UTC", "Asia/Kuala_Lumpur", "America/New_York", "Pacific/Auckland"}) {
            Fixture f = new Fixture(ZoneId.of(zone));
            User u = f.newUser();
            Event full = f.event(Duration.ofHours(48), 10, "100.00");
            Event half = f.event(Duration.ofHours(30), 10, "100.00");
            Event none = f.event(Duration.ofHours(12), 10, "100.00");
            Booking b1 = f.hub.bookings.book(u.getId(), full.getId(), TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null);
            Booking b2 = f.hub.bookings.book(u.getId(), half.getId(), TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null);
            Booking b3 = f.hub.bookings.book(u.getId(), none.getId(), TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null);
            assertEquals("105.00", f.hub.bookings.cancel(u.getId(), b1.getId()).getRefundAmount().toPlainString());
            assertEquals("52.50", f.hub.bookings.cancel(u.getId(), b2.getId()).getRefundAmount().toPlainString());
            assertThrows(BusinessRuleException.class, () -> f.hub.bookings.cancel(u.getId(), b3.getId()));
        }
    }

    @Test
    @DisplayName("TC-SYS-INT-03 | SYS-INT | Unicode event names (Japanese, Arabic, accented, emoji) and user names are stored and searchable unchanged")
    void unicodeRoundTrip() {
        Fixture f = new Fixture();
        f.hub.events.createEvent("音楽祭 🎵", "東京ドーム", f.now().plusDays(3), 10, BigDecimal.TEN);
        f.hub.events.createEvent("مهرجان الصيف", "القاهرة", f.now().plusDays(4), 10, BigDecimal.TEN);
        f.hub.events.createEvent("Café Müller Konzert", "Wien", f.now().plusDays(5), 10, BigDecimal.TEN);
        assertEquals(1, f.hub.events.search("音楽祭").size());
        assertEquals(1, f.hub.events.search("مهرجان").size());
        assertEquals(1, f.hub.events.search("CAFÉ").size());
        User u = f.hub.users.register("Zoë 李雷", "zoe@example.com", Fixture.PASSWORD);
        assertEquals("Zoë 李雷", f.hub.users.findById(u.getId()).getName());
    }

    @Test
    @DisplayName("TC-SYS-INT-04 | SYS-INT | Password with non-ASCII letters ('pässwörd1') is hashed consistently (UTF-8) and exact match is required")
    void charsetPassword() {
        Fixture f = new Fixture();
        f.hub.users.register("Heidi", "heidi@example.com", "pässwörd1");
        assertEquals("heidi@example.com", f.hub.users.login("heidi@example.com", "pässwörd1").getEmail());
        assertThrows(AuthenticationException.class, () -> f.hub.users.login("heidi@example.com", "passwörd1"));
    }

    @Test
    @DisplayName("TC-SYS-INT-05 | SYS-INT | Integration of users, events, pricing, payment and booking: wallet booking then full-refund cancel restores wallet and seats")
    void componentIntegrationWallet() {
        Fixture f = new Fixture();
        User u = f.newUser();
        Event e = f.standardEvent();
        Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.VIP, 5, "VIP20", PaymentMethod.WALLET, null);
        assertEquals("756.00", b.getTotal().toPlainString());
        assertEquals("4244.00", u.getWalletBalance().toPlainString());
        assertEquals(995, e.getAvailable());
        f.hub.bookings.cancel(u.getId(), b.getId());
        assertEquals("5000.00", u.getWalletBalance().toPlainString());
        assertEquals(1000, e.getAvailable());
        assertEquals(BookingStatus.CANCELLED, f.hub.bookings.findById(b.getId()).getStatus());
    }

    @Test
    @DisplayName("TC-SYS-INT-06 | SYS-INT | Card payment cancelled with refund leaves the wallet untouched (external gateway simulated); all failures share one exception type")
    void componentIntegrationCard() {
        Fixture f = new Fixture();
        User u = f.newUser();
        Event e = f.standardEvent();
        Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 1, "", PaymentMethod.CARD, Fixture.VALID_CARD);
        f.hub.bookings.cancel(u.getId(), b.getId());
        assertEquals("5000.00", u.getWalletBalance().toPlainString());
        assertThrows(TicketHubException.class, () -> f.hub.bookings.cancel(u.getId(), b.getId()));
    }
}
