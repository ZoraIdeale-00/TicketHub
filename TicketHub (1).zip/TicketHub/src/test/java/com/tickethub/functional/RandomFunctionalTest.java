package com.tickethub.functional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.exception.TicketHubException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.Booking;
import com.tickethub.model.BookingStatus;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.PromoCode;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.service.PricingService;
import com.tickethub.service.UserService;
import com.tickethub.support.Fixture;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** Random testing with a fixed seed (42) so every run is reproducible. */
class RandomFunctionalTest {
    private static final long SEED = 42L;

    @Test
    @DisplayName("TC-RND-01 | FR-05 | 1000 random quantities in [-50,60]: accepted exactly when in 1..10")
    void randomQuantities() {
        Random r = new Random(SEED);
        PricingService pricing = new PricingService();
        for (int i = 0; i < 1000; i++) {
            int qty = r.nextInt(111) - 50;
            boolean expectValid = qty >= 1 && qty <= 10;
            if (expectValid) {
                assertDoesNotThrow(() -> pricing.calculateTotal(new BigDecimal("20.00"), TicketType.STANDARD, qty, PromoCode.NONE));
            } else {
                assertThrows(ValidationException.class,
                        () -> pricing.calculateTotal(new BigDecimal("20.00"), TicketType.STANDARD, qty, PromoCode.NONE));
            }
        }
    }

    @Test
    @DisplayName("TC-RND-02 | FR-06 | 2000 random price/type/qty/promo inputs: total >= 0, 2 decimals, promo never raises price, ordering STUDENT<=STANDARD<=VIP")
    void randomPricingInvariants() {
        Random r = new Random(SEED);
        PricingService pricing = new PricingService();
        PromoCode[] promos = PromoCode.values();
        for (int i = 0; i < 2000; i++) {
            BigDecimal base = BigDecimal.valueOf(r.nextInt(1_000_001), 2); // 0.00 .. 10000.00
            int qty = 1 + r.nextInt(10);
            PromoCode promo = promos[r.nextInt(promos.length)];
            BigDecimal student = pricing.calculateTotal(base, TicketType.STUDENT, qty, promo);
            BigDecimal standard = pricing.calculateTotal(base, TicketType.STANDARD, qty, promo);
            BigDecimal vip = pricing.calculateTotal(base, TicketType.VIP, qty, promo);
            BigDecimal noPromo = pricing.calculateTotal(base, TicketType.STANDARD, qty, PromoCode.NONE);
            assertTrue(student.signum() >= 0);
            assertEquals(2, standard.scale());
            assertTrue(standard.compareTo(noPromo) <= 0);
            assertTrue(student.compareTo(standard) <= 0 && standard.compareTo(vip) <= 0);
        }
    }

    @Test
    @DisplayName("TC-RND-03 | FR-01 | 1000 random strings as name/email/password: only expected business exceptions, never a crash")
    void randomRegistrationInputs() {
        Random r = new Random(SEED);
        UserService users = new UserService();
        for (int i = 0; i < 1000; i++) {
            String name = randomString(r, r.nextInt(60));
            String email = randomString(r, r.nextInt(30)) + (r.nextBoolean() ? "@" : "") + randomString(r, r.nextInt(10));
            String password = randomString(r, r.nextInt(25));
            try {
                users.register(name, email, password);
            } catch (TicketHubException expected) {
                // fine: a controlled rejection
            }
        }
    }

    @Test
    @DisplayName("TC-RND-04 | FR-01 | 500 randomly generated well-formed emails accepted; same emails with '@' removed rejected")
    void randomEmails() {
        Random r = new Random(SEED);
        UserService users = new UserService();
        for (int i = 0; i < 500; i++) {
            String local = lower(r, 1 + r.nextInt(10)) + i;
            String domain = lower(r, 1 + r.nextInt(8)) + ".com";
            users.register("Random User", local + "@" + domain, "Passw0rd1");
            String broken = local + domain;
            assertThrows(ValidationException.class, () -> users.register("Random User", broken, "Passw0rd1"));
        }
        assertEquals(500, users.count());
    }

    @Test
    @DisplayName("TC-RND-05 | FR-05/08 | 400 random book/cancel operations keep seat counts consistent (available = capacity - confirmed seats)")
    void randomBookCancelSequence() {
        Random r = new Random(SEED);
        Fixture f = new Fixture();
        Event event = f.event(Duration.ofDays(10), 60, "10.00");
        List<User> people = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            people.add(f.newUser());
        }
        List<Booking> made = new ArrayList<>();
        for (int i = 0; i < 400; i++) {
            User u = people.get(r.nextInt(people.size()));
            try {
                if (r.nextInt(3) > 0 || made.isEmpty()) {
                    made.add(f.hub.bookings.book(u.getId(), event.getId(), TicketType.STANDARD, 1 + r.nextInt(10), "",
                            PaymentMethod.WALLET, null));
                } else {
                    Booking b = made.get(r.nextInt(made.size()));
                    f.hub.bookings.cancel(b.getUserId(), b.getId());
                }
            } catch (TicketHubException expected) {
                // sold out / already cancelled are legitimate outcomes
            }
            int confirmedSeats = 0;
            for (User p : people) {
                for (Booking b : f.hub.bookings.forUser(p.getId())) {
                    if (b.getStatus() == BookingStatus.CONFIRMED) {
                        confirmedSeats += b.getQuantity();
                    }
                }
            }
            assertEquals(60 - confirmedSeats, event.getAvailable());
        }
    }

    private static String lower(Random r, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append((char) ('a' + r.nextInt(26)));
        }
        return sb.toString();
    }

    private static String randomString(Random r, int len) {
        String alphabet = "abcXYZ019 @._-+'\";<>%é中";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append(alphabet.charAt(r.nextInt(alphabet.length())));
        }
        return sb.toString();
    }
}
