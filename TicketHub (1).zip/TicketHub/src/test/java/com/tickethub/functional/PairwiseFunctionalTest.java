package com.tickethub.functional;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.tickethub.model.Booking;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.support.Fixture;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Pairwise (all-pairs) test design for the booking flow.
 * Factors: ticket type (3) x promo code (3) x payment method (3) x quantity (1, 5, 10).
 * Exhaustive = 81 combinations; an L9 orthogonal array covers every pair of values in 9 tests.
 * Event base price is 100.00.
 */
class PairwiseFunctionalTest {
    private Fixture f;
    private Event event;

    @BeforeEach
    void setUp() {
        f = new Fixture();
        event = f.standardEvent();
    }

    private void run(TicketType type, String promo, PaymentMethod method, int qty, String expectedTotal) {
        User u = f.newUser();
        String ref = method == PaymentMethod.CARD ? Fixture.VALID_CARD
                : method == PaymentMethod.BANK ? Fixture.VALID_BANK : null;
        Booking b = f.hub.bookings.book(u.getId(), event.getId(), type, qty, promo, method, ref);
        assertEquals(expectedTotal, b.getTotal().toPlainString());
        assertEquals(1000 - qty, event.getAvailable());
    }

    @Test
    @DisplayName("TC-PW-01 | FR-05/06/07 | STANDARD, no promo, CARD, qty 1 -> 105.00")
    void pw1() {
        run(TicketType.STANDARD, "", PaymentMethod.CARD, 1, "105.00");
    }

    @Test
    @DisplayName("TC-PW-02 | FR-05/06/07 | STANDARD, SAVE10, WALLET, qty 5 -> 425.25")
    void pw2() {
        run(TicketType.STANDARD, "SAVE10", PaymentMethod.WALLET, 5, "425.25");
    }

    @Test
    @DisplayName("TC-PW-03 | FR-05/06/07 | STANDARD, VIP20, BANK, qty 10 -> 756.00")
    void pw3() {
        run(TicketType.STANDARD, "VIP20", PaymentMethod.BANK, 10, "756.00");
    }

    @Test
    @DisplayName("TC-PW-04 | FR-05/06/07 | VIP, no promo, WALLET, qty 10 -> 1890.00")
    void pw4() {
        run(TicketType.VIP, null, PaymentMethod.WALLET, 10, "1890.00");
    }

    @Test
    @DisplayName("TC-PW-05 | FR-05/06/07 | VIP, SAVE10, BANK, qty 1 -> 189.00")
    void pw5() {
        run(TicketType.VIP, "SAVE10", PaymentMethod.BANK, 1, "189.00");
    }

    @Test
    @DisplayName("TC-PW-06 | FR-05/06/07 | VIP, VIP20, CARD, qty 5 -> 756.00")
    void pw6() {
        run(TicketType.VIP, "VIP20", PaymentMethod.CARD, 5, "756.00");
    }

    @Test
    @DisplayName("TC-PW-07 | FR-05/06/07 | STUDENT, no promo, BANK, qty 5 -> 236.25")
    void pw7() {
        run(TicketType.STUDENT, "", PaymentMethod.BANK, 5, "236.25");
    }

    @Test
    @DisplayName("TC-PW-08 | FR-05/06/07 | STUDENT, SAVE10, CARD, qty 10 -> 425.25")
    void pw8() {
        run(TicketType.STUDENT, "SAVE10", PaymentMethod.CARD, 10, "425.25");
    }

    @Test
    @DisplayName("TC-PW-09 | FR-05/06/07 | STUDENT, VIP20, WALLET, qty 1 -> 42.00")
    void pw9() {
        run(TicketType.STUDENT, "VIP20", PaymentMethod.WALLET, 1, "42.00");
    }
}
