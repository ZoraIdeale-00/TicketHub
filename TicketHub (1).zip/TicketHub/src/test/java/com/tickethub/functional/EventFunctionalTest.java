package com.tickethub.functional;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.exception.NotFoundException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.Event;
import com.tickethub.support.Fixture;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** FR-03 event creation and FR-04 search. */
class EventFunctionalTest {
    private Fixture f;

    @BeforeEach
    void setUp() {
        f = new Fixture();
    }

    private Event create(int capacity, String price) {
        return f.event(Duration.ofDays(5), capacity, price);
    }

    @Test
    @DisplayName("TC-EP-10 | FR-03 | Valid event (name, venue, future date, capacity 500, price 150.00) -> created with all seats available")
    void epValidEvent() {
        Event e = create(500, "150.00");
        assertEquals(500, e.getAvailable());
        assertEquals(f.hub.events.findById(e.getId()).getId(), e.getId());
    }

    @Test
    @DisplayName("TC-EP-11 | FR-03 | Blank event name or venue -> rejected")
    void epBlankNameVenue() {
        assertThrows(ValidationException.class,
                () -> f.hub.events.createEvent("  ", "Hall", f.now().plusDays(1), 10, new BigDecimal("10")));
        assertThrows(ValidationException.class,
                () -> f.hub.events.createEvent("Show", "", f.now().plusDays(1), 10, new BigDecimal("10")));
    }

    @Test
    @DisplayName("TC-EP-12 | FR-04 | Keyword search matches name or venue, case-insensitively")
    void epSearchKeyword() {
        f.hub.events.createEvent("Rock Night", "Arena One", f.now().plusDays(3), 100, new BigDecimal("50"));
        f.hub.events.createEvent("Jazz Evening", "Blue Hall", f.now().plusDays(4), 100, new BigDecimal("50"));
        assertEquals(1, f.hub.events.search("ROCK").size());
        assertEquals(1, f.hub.events.search("blue hall").size());
        assertEquals(0, f.hub.events.search("opera").size());
    }

    @Test
    @DisplayName("TC-EP-13 | FR-04 | Blank keyword returns all upcoming events sorted by date")
    void epSearchBlankSorted() {
        f.hub.events.createEvent("Later", "Hall", f.now().plusDays(9), 10, new BigDecimal("1"));
        f.hub.events.createEvent("Sooner", "Hall", f.now().plusDays(2), 10, new BigDecimal("1"));
        List<Event> all = f.hub.events.search("");
        assertEquals("Sooner", all.get(0).getName());
        assertEquals(2, all.size());
    }

    @Test
    @DisplayName("TC-EP-14 | FR-04 | Event that has already started is not listed in search")
    void epSearchHidesPast() {
        f.event(Duration.ofHours(2), 10, "10.00");
        f.clock.advance(Duration.ofHours(3));
        assertTrue(f.hub.events.search("").isEmpty());
    }

    @Test
    @DisplayName("TC-BVA-13 | FR-03 | Capacity 0 (min-1) -> rejected")
    void bvaCapacityMinMinus1() {
        assertThrows(ValidationException.class, () -> create(0, "10"));
    }

    @Test
    @DisplayName("TC-BVA-14 | FR-03 | Capacity 1 (min) -> accepted")
    void bvaCapacityMin() {
        assertDoesNotThrow(() -> create(1, "10"));
    }

    @Test
    @DisplayName("TC-BVA-15 | FR-03 | Capacity 10000 (max) -> accepted")
    void bvaCapacityMax() {
        assertDoesNotThrow(() -> create(10_000, "10"));
    }

    @Test
    @DisplayName("TC-BVA-16 | FR-03 | Capacity 10001 (max+1) -> rejected")
    void bvaCapacityMaxPlus1() {
        assertThrows(ValidationException.class, () -> create(10_001, "10"));
    }

    @Test
    @DisplayName("TC-BVA-17 | FR-03 | Price -0.01 (min-1) -> rejected")
    void bvaPriceMinMinus1() {
        assertThrows(ValidationException.class, () -> create(10, "-0.01"));
    }

    @Test
    @DisplayName("TC-BVA-18 | FR-03 | Price 0.00 (min, free event) -> accepted")
    void bvaPriceMin() {
        assertDoesNotThrow(() -> create(10, "0.00"));
    }

    @Test
    @DisplayName("TC-BVA-19 | FR-03 | Price 10000.00 (max) -> accepted")
    void bvaPriceMax() {
        assertDoesNotThrow(() -> create(10, "10000.00"));
    }

    @Test
    @DisplayName("TC-BVA-20 | FR-03 | Price 10000.01 (max+1) -> rejected")
    void bvaPriceMaxPlus1() {
        assertThrows(ValidationException.class, () -> create(10, "10000.01"));
    }

    @Test
    @DisplayName("TC-BVA-21 | FR-03 | Event date equal to 'now' -> rejected; now + 1 minute -> accepted")
    void bvaEventDate() {
        assertThrows(ValidationException.class,
                () -> f.hub.events.createEvent("Show", "Hall", f.now(), 10, new BigDecimal("10")));
        assertDoesNotThrow(
                () -> f.hub.events.createEvent("Show", "Hall", f.now().plusMinutes(1), 10, new BigDecimal("10")));
    }

    @Test
    @DisplayName("TC-EG-10 | FR-03 | Null date or null price -> ValidationException (no NullPointerException)")
    void egNullDateAndPrice() {
        assertThrows(ValidationException.class,
                () -> f.hub.events.createEvent("Show", "Hall", null, 10, new BigDecimal("10")));
        assertThrows(ValidationException.class,
                () -> f.hub.events.createEvent("Show", "Hall", f.now().plusDays(1), 10, null));
    }

    @Test
    @DisplayName("TC-EG-11 | FR-04 | Looking up an event id that does not exist -> NotFoundException")
    void egUnknownEvent() {
        assertThrows(NotFoundException.class, () -> f.hub.events.findById(999));
    }
}
