package com.tickethub.functional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.tickethub.exception.ValidationException;
import com.tickethub.model.PromoCode;
import com.tickethub.model.TicketType;
import com.tickethub.service.PricingService;
import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** FR-05 quantity limits and FR-06 pricing rules (BVA, EP, error guessing). */
class PricingFunctionalTest {
    private final PricingService pricing = new PricingService();
    private static final BigDecimal HUNDRED = new BigDecimal("100.00");

    private String total(String base, TicketType t, int qty, PromoCode p) {
        return pricing.calculateTotal(new BigDecimal(base), t, qty, p).toPlainString();
    }

    @Test
    @DisplayName("TC-EP-15 | FR-06 | STANDARD x1, no promo, base 100.00 -> 105.00 (5% service fee)")
    void epStandard() {
        assertEquals("105.00", total("100.00", TicketType.STANDARD, 1, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-EP-16 | FR-06 | VIP ticket costs 2x base: VIP x1 -> 210.00")
    void epVip() {
        assertEquals("210.00", total("100.00", TicketType.VIP, 1, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-EP-17 | FR-06 | STUDENT ticket costs 0.5x base: STUDENT x1 -> 52.50")
    void epStudent() {
        assertEquals("52.50", total("100.00", TicketType.STUDENT, 1, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-EP-18 | FR-06 | SAVE10 promo: STANDARD x1 -> 94.50")
    void epSave10() {
        assertEquals("94.50", total("100.00", TicketType.STANDARD, 1, PromoCode.SAVE10));
    }

    @Test
    @DisplayName("TC-EP-19 | FR-06 | VIP20 promo: STANDARD x1 -> 84.00")
    void epVip20() {
        assertEquals("84.00", total("100.00", TicketType.STANDARD, 1, PromoCode.VIP20));
    }

    @Test
    @DisplayName("TC-BVA-22 | FR-05 | Quantity 0 (min-1) -> rejected")
    void bvaQtyMinMinus1() {
        assertThrows(ValidationException.class, () -> total("100.00", TicketType.STANDARD, 0, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-BVA-23 | FR-05 | Quantity 1 (min) -> 105.00")
    void bvaQtyMin() {
        assertEquals("105.00", total("100.00", TicketType.STANDARD, 1, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-BVA-24 | FR-05 | Quantity 10 (max) -> 945.00 (group discount applies)")
    void bvaQtyMax() {
        assertEquals("945.00", total("100.00", TicketType.STANDARD, 10, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-BVA-25 | FR-05 | Quantity 11 (max+1) -> rejected")
    void bvaQtyMaxPlus1() {
        assertThrows(ValidationException.class, () -> total("100.00", TicketType.STANDARD, 11, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-BVA-26 | FR-06 | Quantity 4 (group threshold-1) -> 420.00, no group discount")
    void bvaGroupBelow() {
        assertEquals("420.00", total("100.00", TicketType.STANDARD, 4, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-BVA-27 | FR-06 | Quantity 5 (group threshold) -> 472.50, 10% group discount applied")
    void bvaGroupAt() {
        assertEquals("472.50", total("100.00", TicketType.STANDARD, 5, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-EG-12 | FR-06 | Rounding: base 0.10 x1 = 0.105 -> rounds half-up to 0.11")
    void egRoundingHalfUp() {
        assertEquals("0.11", total("0.10", TicketType.STANDARD, 1, PromoCode.NONE));
    }

    @Test
    @DisplayName("TC-EG-13 | FR-06 | Rounding: base 33.33 STUDENT with SAVE10 = 15.748425 -> 15.75")
    void egRoundingComplex() {
        assertEquals("15.75", total("33.33", TicketType.STUDENT, 1, PromoCode.SAVE10));
    }

    @Test
    @DisplayName("TC-EG-14 | FR-06 | Free event (base 0.00) -> total 0.00")
    void egFreeEvent() {
        assertEquals("0.00", total("0.00", TicketType.VIP, 3, PromoCode.VIP20));
    }

    @Test
    @DisplayName("TC-EG-15 | FR-06 | Promo and group discounts stack multiplicatively: x5 + SAVE10 -> 425.25")
    void egDiscountStacking() {
        assertEquals("425.25", total("100.00", TicketType.STANDARD, 5, PromoCode.SAVE10));
    }

    @Test
    @DisplayName("TC-EG-16 | FR-06 | Promo parsing: lower-case 'save10' and unknown 'FREE100' rejected; blank/null = none")
    void egPromoParsing() {
        assertThrows(ValidationException.class, () -> PromoCode.parse("save10"));
        assertThrows(ValidationException.class, () -> PromoCode.parse("FREE100"));
        assertEquals(PromoCode.NONE, PromoCode.parse(""));
        assertEquals(PromoCode.NONE, PromoCode.parse(null));
        assertEquals(PromoCode.SAVE10, PromoCode.parse(" SAVE10 "));
    }

    @Test
    @DisplayName("TC-EG-17 | FR-06 | Null base price / ticket type / promo -> ValidationException")
    void egNulls() {
        assertThrows(ValidationException.class, () -> pricing.calculateTotal(null, TicketType.VIP, 1, PromoCode.NONE));
        assertThrows(ValidationException.class, () -> pricing.calculateTotal(HUNDRED, null, 1, PromoCode.NONE));
        assertThrows(ValidationException.class, () -> pricing.calculateTotal(HUNDRED, TicketType.VIP, 1, null));
    }
}
