package com.tickethub.functional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.exception.BusinessRuleException;
import com.tickethub.exception.NotFoundException;
import com.tickethub.exception.PaymentException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.Booking;
import com.tickethub.model.BookingStatus;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.support.Fixture;
import java.time.Duration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** FR-05 booking, FR-07 payment and FR-08 cancellation. */
class BookingFunctionalTest {
    private Fixture f;
    private User user;

    @BeforeEach
    void setUp() {
        f = new Fixture();
        user = f.newUser();
    }

    private Booking bookWallet(Event e, int qty) {
        return f.hub.bookings.book(user.getId(), e.getId(), TicketType.STANDARD, qty, "", PaymentMethod.WALLET, null);
    }

    // ---------------- Equivalence partitioning ----------------

    @Test
    @DisplayName("TC-EP-20 | FR-05 | Valid booking reduces available seats and is CONFIRMED")
    void epBookingReducesSeats() {
        Event e = f.standardEvent();
        Booking b = f.hub.bookings.book(user.getId(), e.getId(), TicketType.STANDARD, 2, "",
                PaymentMethod.CARD, Fixture.VALID_CARD);
        assertEquals(998, e.getAvailable());
        assertEquals(BookingStatus.CONFIRMED, b.getStatus());
    }

    @Test
    @DisplayName("TC-EP-21 | FR-07 | Card partition: valid Luhn 16-digit card -> payment accepted")
    void epCardValid() {
        Event e = f.standardEvent();
        Booking b = f.hub.bookings.book(user.getId(), e.getId(), TicketType.STANDARD, 1, "",
                PaymentMethod.CARD, Fixture.VALID_CARD);
        assertTrue(b.getTransactionId().startsWith("TXN-"));
    }

    @Test
    @DisplayName("TC-EP-22 | FR-07 | Card partition: 16 digits but fails Luhn check -> PaymentException")
    void epCardBadLuhn() {
        Event e = f.standardEvent();
        assertThrows(PaymentException.class, () -> f.hub.bookings.book(user.getId(), e.getId(),
                TicketType.STANDARD, 1, "", PaymentMethod.CARD, Fixture.BAD_LUHN_CARD));
    }

    @Test
    @DisplayName("TC-EP-23 | FR-07 | Bank partition: 8-12 digit reference accepted, 'ABC123' rejected")
    void epBank() {
        Event e = f.standardEvent();
        f.hub.bookings.book(user.getId(), e.getId(), TicketType.STANDARD, 1, "", PaymentMethod.BANK, "12345678");
        assertThrows(PaymentException.class, () -> f.hub.bookings.book(user.getId(), e.getId(),
                TicketType.STANDARD, 1, "", PaymentMethod.BANK, "ABC123"));
    }

    @Test
    @DisplayName("TC-EP-24 | FR-07 | Wallet partition: sufficient balance debited by exactly the booking total")
    void epWalletDebit() {
        Event e = f.standardEvent();
        bookWallet(e, 1);
        assertEquals("4895.00", user.getWalletBalance().toPlainString());
    }

    @Test
    @DisplayName("TC-EP-25 | FR-05 | Unknown user id -> NotFoundException")
    void epUnknownUser() {
        Event e = f.standardEvent();
        assertThrows(NotFoundException.class, () -> f.hub.bookings.book(9999, e.getId(), TicketType.STANDARD, 1, "",
                PaymentMethod.WALLET, null));
    }

    // ---------------- Boundary value analysis ----------------

    @Test
    @DisplayName("TC-BVA-28 | FR-05 | Booking exactly the remaining seats (3 of 3) -> accepted, event sold out")
    void bvaSeatsExact() {
        Event e = f.event(Duration.ofDays(5), 3, "10.00");
        bookWallet(e, 3);
        assertEquals(0, e.getAvailable());
    }

    @Test
    @DisplayName("TC-BVA-29 | FR-05 | Booking one more than remaining seats (4 of 3) -> 'Not enough seats'")
    void bvaSeatsExceeded() {
        Event e = f.event(Duration.ofDays(5), 3, "10.00");
        BusinessRuleException ex = assertThrows(BusinessRuleException.class, () -> bookWallet(e, 4));
        assertEquals("Not enough seats available", ex.getMessage());
        assertEquals(3, e.getAvailable());
    }

    @Test
    @DisplayName("TC-BVA-30 | FR-05 | Quantity 0 and 11 through the booking service -> ValidationException")
    void bvaBookingQtyLimits() {
        Event e = f.standardEvent();
        assertThrows(ValidationException.class, () -> bookWallet(e, 0));
        assertThrows(ValidationException.class, () -> bookWallet(e, 11));
    }

    @Test
    @DisplayName("TC-BVA-31 | FR-08 | Cancel exactly 48h before event (full-refund boundary) -> 100% refund")
    void bvaCancel48h() {
        Event e = f.event(Duration.ofHours(48), 10, "100.00");
        Booking b = bookWallet(e, 1);
        f.hub.bookings.cancel(user.getId(), b.getId());
        assertEquals("105.00", b.getRefundAmount().toPlainString());
        assertEquals("5000.00", user.getWalletBalance().toPlainString());
    }

    @Test
    @DisplayName("TC-BVA-32 | FR-08 | Cancel 47h59m before event (just inside partial band) -> 50% refund")
    void bvaCancel47h59() {
        Event e = f.event(Duration.ofHours(47).plusMinutes(59), 10, "100.00");
        Booking b = bookWallet(e, 1);
        f.hub.bookings.cancel(user.getId(), b.getId());
        assertEquals("52.50", b.getRefundAmount().toPlainString());
        assertEquals("4947.50", user.getWalletBalance().toPlainString());
    }

    @Test
    @DisplayName("TC-BVA-33 | FR-08 | Cancel exactly 24h before event (lower boundary) -> allowed, 50% refund")
    void bvaCancel24h() {
        Event e = f.event(Duration.ofHours(24), 10, "100.00");
        Booking b = bookWallet(e, 1);
        f.hub.bookings.cancel(user.getId(), b.getId());
        assertEquals("52.50", b.getRefundAmount().toPlainString());
    }

    @Test
    @DisplayName("TC-BVA-34 | FR-08 | Cancel 23h59m before event -> rejected, booking stays CONFIRMED")
    void bvaCancel23h59() {
        Event e = f.event(Duration.ofHours(23).plusMinutes(59), 10, "100.00");
        Booking b = bookWallet(e, 1);
        assertThrows(BusinessRuleException.class, () -> f.hub.bookings.cancel(user.getId(), b.getId()));
        assertEquals(BookingStatus.CONFIRMED, b.getStatus());
    }

    // ---------------- Error guessing ----------------

    @Test
    @DisplayName("TC-EG-18 | FR-07 | Failed payment must not consume seats (invalid card, 5 seats requested)")
    void egFailedPaymentReleasesSeats() {
        Event e = f.standardEvent();
        assertThrows(PaymentException.class, () -> f.hub.bookings.book(user.getId(), e.getId(),
                TicketType.STANDARD, 5, "", PaymentMethod.CARD, Fixture.BAD_LUHN_CARD));
        assertEquals(1000, e.getAvailable());
        assertTrue(f.hub.bookings.forUser(user.getId()).isEmpty());
    }

    @Test
    @DisplayName("TC-EG-19 | FR-07 | Insufficient wallet balance -> PaymentException, balance and seats unchanged")
    void egInsufficientWallet() {
        Event e = f.event(Duration.ofDays(5), 100, "10000.00");
        assertThrows(PaymentException.class, () -> bookWallet(e, 1));
        assertEquals("5000.00", user.getWalletBalance().toPlainString());
        assertEquals(100, e.getAvailable());
    }

    @Test
    @DisplayName("TC-EG-20 | FR-07 | Card number with spaces '4111 1111 1111 1111' -> rejected (digits only)")
    void egCardWithSpaces() {
        Event e = f.standardEvent();
        assertThrows(PaymentException.class, () -> f.hub.bookings.book(user.getId(), e.getId(),
                TicketType.STANDARD, 1, "", PaymentMethod.CARD, "4111 1111 1111 1111"));
    }

    @Test
    @DisplayName("TC-EG-21 | FR-07 | Null card reference -> PaymentException (no NullPointerException)")
    void egNullCardReference() {
        Event e = f.standardEvent();
        assertThrows(PaymentException.class, () -> f.hub.bookings.book(user.getId(), e.getId(),
                TicketType.STANDARD, 1, "", PaymentMethod.CARD, null));
    }

    @Test
    @DisplayName("TC-EG-22 | FR-05 | Booking an event that started after it was listed -> 'Event has already started'")
    void egEventStarted() {
        Event e = f.event(Duration.ofHours(1), 10, "10.00");
        f.clock.advance(Duration.ofHours(2));
        BusinessRuleException ex = assertThrows(BusinessRuleException.class, () -> bookWallet(e, 1));
        assertEquals("Event has already started", ex.getMessage());
    }

    @Test
    @DisplayName("TC-EG-23 | FR-05 | Unknown event id -> NotFoundException")
    void egUnknownEvent() {
        assertThrows(NotFoundException.class, () -> f.hub.bookings.book(user.getId(), 4242, TicketType.STANDARD, 1,
                "", PaymentMethod.WALLET, null));
    }

    @Test
    @DisplayName("TC-EG-24 | FR-08 | Cancelling the same booking twice -> second attempt rejected, seats released once")
    void egDoubleCancel() {
        Event e = f.standardEvent();
        Booking b = bookWallet(e, 2);
        f.hub.bookings.cancel(user.getId(), b.getId());
        assertThrows(BusinessRuleException.class, () -> f.hub.bookings.cancel(user.getId(), b.getId()));
        assertEquals(1000, e.getAvailable());
    }

    @Test
    @DisplayName("TC-EG-25 | FR-08 | Cancelling another user's booking -> rejected")
    void egCancelOthersBooking() {
        Event e = f.standardEvent();
        Booking b = bookWallet(e, 1);
        User other = f.newUser();
        assertThrows(BusinessRuleException.class, () -> f.hub.bookings.cancel(other.getId(), b.getId()));
        assertEquals(BookingStatus.CONFIRMED, b.getStatus());
    }

    @Test
    @DisplayName("TC-EG-26 | FR-08 | Cancelling a booking id that does not exist -> NotFoundException")
    void egCancelUnknownBooking() {
        assertThrows(NotFoundException.class, () -> f.hub.bookings.cancel(user.getId(), 777));
    }

    @Test
    @DisplayName("TC-EG-27 | FR-05 | Free event (price 0.00) booked with no payment details -> total 0.00 and CONFIRMED")
    void egFreeEvent() {
        Event e = f.event(Duration.ofDays(3), 50, "0.00");
        Booking b = f.hub.bookings.book(user.getId(), e.getId(), TicketType.STANDARD, 2, "",
                PaymentMethod.CARD, null);
        assertEquals("0.00", b.getTotal().toPlainString());
        assertEquals(BookingStatus.CONFIRMED, b.getStatus());
    }

    @Test
    @DisplayName("TC-EG-28 | FR-05 | Missing ticket type or payment method -> ValidationException")
    void egMissingTypeOrMethod() {
        Event e = f.standardEvent();
        assertThrows(ValidationException.class, () -> f.hub.bookings.book(user.getId(), e.getId(), null, 1, "",
                PaymentMethod.WALLET, null));
        assertThrows(ValidationException.class, () -> f.hub.bookings.book(user.getId(), e.getId(),
                TicketType.VIP, 1, "", null, null));
    }
}
