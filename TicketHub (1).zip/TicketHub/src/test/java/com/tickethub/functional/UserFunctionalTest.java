package com.tickethub.functional;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.exception.AuthenticationException;
import com.tickethub.exception.BusinessRuleException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.User;
import com.tickethub.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** FR-01 registration and FR-02 login: equivalence partitioning, BVA and error guessing. */
class UserFunctionalTest {
    private UserService users;
    private int n;

    @BeforeEach
    void setUp() {
        users = new UserService();
        n = 0;
    }

    private User registerName(String name) {
        return users.register(name, "u" + (n++) + "@example.com", "Passw0rd1");
    }

    private User registerPassword(String password) {
        return users.register("Alice", "u" + (n++) + "@example.com", password);
    }

    // ---------------- Equivalence partitioning ----------------

    @Test
    @DisplayName("TC-EP-01 | FR-01 | Valid name, email and password -> user registered with welcome credit 5000.00")
    void epValidRegistration() {
        User u = users.register("Alice Tan", "alice@example.com", "Passw0rd1");
        assertEquals("alice@example.com", u.getEmail());
        assertEquals("5000.00", u.getWalletBalance().toPlainString());
    }

    @Test
    @DisplayName("TC-EP-02 | FR-01 | Invalid email partition: no '@' sign -> rejected")
    void epEmailNoAt() {
        assertThrows(ValidationException.class, () -> users.register("Alice", "alice.example.com", "Passw0rd1"));
    }

    @Test
    @DisplayName("TC-EP-03 | FR-01 | Invalid email partition: no top-level domain (user@site) -> rejected")
    void epEmailNoTld() {
        assertThrows(ValidationException.class, () -> users.register("Alice", "alice@site", "Passw0rd1"));
    }

    @Test
    @DisplayName("TC-EP-04 | FR-01 | Invalid password partition: digits only -> rejected")
    void epPasswordDigitsOnly() {
        assertThrows(ValidationException.class, () -> registerPassword("12345678"));
    }

    @Test
    @DisplayName("TC-EP-05 | FR-01 | Invalid password partition: letters only -> rejected")
    void epPasswordLettersOnly() {
        assertThrows(ValidationException.class, () -> registerPassword("abcdefgh"));
    }

    @Test
    @DisplayName("TC-EP-06 | FR-01 | Duplicate email partition -> rejected with 'already registered'")
    void epDuplicateEmail() {
        users.register("Alice", "alice@example.com", "Passw0rd1");
        BusinessRuleException e = assertThrows(BusinessRuleException.class,
                () -> users.register("Bob", "alice@example.com", "Passw0rd1"));
        assertEquals("Email already registered", e.getMessage());
    }

    @Test
    @DisplayName("TC-EP-07 | FR-02 | Registered user with correct credentials -> login succeeds")
    void epLoginOk() {
        User u = users.register("Alice", "alice@example.com", "Passw0rd1");
        assertEquals(u.getId(), users.login("alice@example.com", "Passw0rd1").getId());
    }

    @Test
    @DisplayName("TC-EP-08 | FR-02 | Registered user with wrong password -> 'Invalid credentials'")
    void epLoginWrongPassword() {
        users.register("Alice", "alice@example.com", "Passw0rd1");
        AuthenticationException e = assertThrows(AuthenticationException.class,
                () -> users.login("alice@example.com", "Wrong1234"));
        assertEquals("Invalid credentials", e.getMessage());
    }

    @Test
    @DisplayName("TC-EP-09 | FR-02 | Unknown email -> 'Invalid credentials' (same message, no user enumeration)")
    void epLoginUnknownEmail() {
        AuthenticationException e = assertThrows(AuthenticationException.class,
                () -> users.login("nobody@example.com", "Passw0rd1"));
        assertEquals("Invalid credentials", e.getMessage());
    }

    // ---------------- Boundary value analysis ----------------

    @Test
    @DisplayName("TC-BVA-01 | FR-01 | Name length 1 (min-1) -> rejected")
    void bvaNameMinMinus1() {
        assertThrows(ValidationException.class, () -> registerName("A"));
    }

    @Test
    @DisplayName("TC-BVA-02 | FR-01 | Name length 2 (min) -> accepted")
    void bvaNameMin() {
        assertDoesNotThrow(() -> registerName("Al"));
    }

    @Test
    @DisplayName("TC-BVA-03 | FR-01 | Name length 3 (min+1) -> accepted")
    void bvaNameMinPlus1() {
        assertDoesNotThrow(() -> registerName("Ali"));
    }

    @Test
    @DisplayName("TC-BVA-04 | FR-01 | Name length 49 (max-1) -> accepted")
    void bvaNameMaxMinus1() {
        assertDoesNotThrow(() -> registerName("A".repeat(49)));
    }

    @Test
    @DisplayName("TC-BVA-05 | FR-01 | Name length 50 (max) -> accepted")
    void bvaNameMax() {
        assertDoesNotThrow(() -> registerName("A".repeat(50)));
    }

    @Test
    @DisplayName("TC-BVA-06 | FR-01 | Name length 51 (max+1) -> rejected")
    void bvaNameMaxPlus1() {
        assertThrows(ValidationException.class, () -> registerName("A".repeat(51)));
    }

    @Test
    @DisplayName("TC-BVA-07 | FR-01 | Password length 7 (min-1) -> rejected")
    void bvaPasswordMinMinus1() {
        assertThrows(ValidationException.class, () -> registerPassword("Pass123"));
    }

    @Test
    @DisplayName("TC-BVA-08 | FR-01 | Password length 8 (min) -> accepted")
    void bvaPasswordMin() {
        assertDoesNotThrow(() -> registerPassword("Pass1234"));
    }

    @Test
    @DisplayName("TC-BVA-09 | FR-01 | Password length 20 (max) -> accepted")
    void bvaPasswordMax() {
        assertDoesNotThrow(() -> registerPassword("Pass" + "1".repeat(16)));
    }

    @Test
    @DisplayName("TC-BVA-10 | FR-01 | Password length 21 (max+1) -> rejected")
    void bvaPasswordMaxPlus1() {
        assertThrows(ValidationException.class, () -> registerPassword("Pass" + "1".repeat(17)));
    }

    @Test
    @DisplayName("TC-BVA-11 | FR-02 | 2 failed logins (lock threshold-1) then correct password -> login succeeds")
    void bvaLockoutBelowThreshold() {
        users.register("Alice", "alice@example.com", "Passw0rd1");
        for (int i = 0; i < 2; i++) {
            assertThrows(AuthenticationException.class, () -> users.login("alice@example.com", "bad"));
        }
        assertDoesNotThrow(() -> users.login("alice@example.com", "Passw0rd1"));
    }

    @Test
    @DisplayName("TC-BVA-12 | FR-02 | 3 failed logins (lock threshold) -> account locked, even correct password refused")
    void bvaLockoutAtThreshold() {
        users.register("Alice", "alice@example.com", "Passw0rd1");
        for (int i = 0; i < 3; i++) {
            assertThrows(AuthenticationException.class, () -> users.login("alice@example.com", "bad"));
        }
        AuthenticationException e = assertThrows(AuthenticationException.class,
                () -> users.login("alice@example.com", "Passw0rd1"));
        assertEquals("Account locked", e.getMessage());
    }

    // ---------------- Error guessing ----------------

    @Test
    @DisplayName("TC-EG-01 | FR-01 | Email with surrounding spaces and capitals -> normalised to lower-case, trimmed")
    void egEmailNormalised() {
        User u = users.register("Alice", "  Alice@Example.COM ", "Passw0rd1");
        assertEquals("alice@example.com", u.getEmail());
    }

    @Test
    @DisplayName("TC-EG-02 | FR-01 | Same email in different letter case -> treated as duplicate")
    void egEmailCaseDuplicate() {
        users.register("Alice", "alice@example.com", "Passw0rd1");
        assertThrows(BusinessRuleException.class, () -> users.register("Alice2", "ALICE@EXAMPLE.COM", "Passw0rd1"));
    }

    @Test
    @DisplayName("TC-EG-03 | FR-01 | Whitespace-only name -> rejected")
    void egBlankName() {
        assertThrows(ValidationException.class, () -> registerName("     "));
    }

    @Test
    @DisplayName("TC-EG-04 | FR-01 | Null name, email and password -> ValidationException (no NullPointerException)")
    void egNulls() {
        assertThrows(ValidationException.class, () -> users.register(null, "a@example.com", "Passw0rd1"));
        assertThrows(ValidationException.class, () -> users.register("Alice", null, "Passw0rd1"));
        assertThrows(ValidationException.class, () -> users.register("Alice", "a@example.com", null));
    }

    @Test
    @DisplayName("TC-EG-05 | FR-01 | SQL-injection style name stored as plain text, other users unaffected")
    void egSqlInjectionName() {
        User u = registerName("x'; DROP TABLE users;--");
        assertEquals("x'; DROP TABLE users;--", u.getName());
        assertEquals(1, users.count());
    }

    @Test
    @DisplayName("TC-EG-06 | FR-01 | Unicode name 'José Müller' accepted and stored unchanged")
    void egUnicodeName() {
        assertEquals("José Müller", registerName("José Müller").getName());
    }

    @Test
    @DisplayName("TC-EG-07 | FR-01 | Email containing double dots or double '@' -> rejected")
    void egMalformedEmails() {
        assertThrows(ValidationException.class, () -> users.register("Alice", "a@@example.com", "Passw0rd1"));
        assertThrows(ValidationException.class, () -> users.register("Alice", "a@example..com", "Passw0rd1"));
        assertThrows(ValidationException.class, () -> users.register("Alice", "@example.com", "Passw0rd1"));
    }

    @Test
    @DisplayName("TC-EG-08 | FR-02 | Null email or password at login -> AuthenticationException")
    void egLoginNulls() {
        assertThrows(AuthenticationException.class, () -> users.login(null, "Passw0rd1"));
        assertThrows(AuthenticationException.class, () -> users.login("a@example.com", null));
    }

    @Test
    @DisplayName("TC-EG-09 | FR-02 | Successful login resets the failed-attempt counter")
    void egLoginResetsCounter() {
        User u = users.register("Alice", "alice@example.com", "Passw0rd1");
        assertThrows(AuthenticationException.class, () -> users.login("alice@example.com", "bad"));
        users.login("alice@example.com", "Passw0rd1");
        assertEquals(0, u.getFailedAttempts());
        assertFalse(u.isLocked());
        assertTrue(u.getPasswordHash().length() == 64);
    }
}
