package com.tickethub.support;

/** Prints measurements in a fixed format so the report can quote them. */
public final class PerfLog {
    private PerfLog() {
    }

    public static void record(String testId, String metric, String value) {
        System.out.println("[PERF] " + testId + " | " + metric + " | " + value);
    }
}
