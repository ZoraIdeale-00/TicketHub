package com.tickethub.support;

import com.tickethub.model.Event;
import com.tickethub.model.User;
import com.tickethub.service.TicketHubSystem;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.concurrent.atomic.AtomicInteger;

/** Builds a fresh TicketHub with a controllable clock plus small helpers used by all test classes. */
public class Fixture {
    public static final String VALID_CARD = "4111111111111111";   // passes Luhn
    public static final String BAD_LUHN_CARD = "4111111111111112"; // 16 digits, fails Luhn
    public static final String VALID_BANK = "123456789";           // 9 digits
    public static final String PASSWORD = "Passw0rd1";

    private final AtomicInteger counter = new AtomicInteger();
    public final MutableClock clock;
    public final TicketHubSystem hub;

    public Fixture() {
        this(ZoneId.of("UTC"));
    }

    public Fixture(ZoneId zone) {
        this.clock = new MutableClock(Instant.parse("2026-10-08T02:00:00Z"), zone);
        this.hub = new TicketHubSystem(clock);
    }

    public LocalDateTime now() {
        return LocalDateTime.now(clock);
    }

    public User newUser() {
        int n = counter.incrementAndGet();
        return hub.users.register("Test User " + n, "user" + n + "@example.com", PASSWORD);
    }

    public Event event(Duration fromNow, int capacity, String price) {
        return hub.events.createEvent("Concert", "Main Hall", now().plus(fromNow), capacity, new BigDecimal(price));
    }

    /** Standard event: 10 days away, 1000 seats, base price 100.00. */
    public Event standardEvent() {
        return event(Duration.ofDays(10), 1000, "100.00");
    }

    public static BigDecimal money(String value) {
        return new BigDecimal(value);
    }
}
