package com.tickethub.acceptance;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tickethub.exception.AuthenticationException;
import com.tickethub.exception.BusinessRuleException;
import com.tickethub.exception.PaymentException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.Booking;
import com.tickethub.model.BookingStatus;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.support.Fixture;
import com.tickethub.support.PerfLog;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * User acceptance tests written as Given / When / Then scenarios.
 * Each scenario verifies one acceptance criterion (AC-xx) agreed with the stakeholder (see docs report, section 4).
 */
class AcceptanceTest {
    private Fixture f;

    @BeforeEach
    void setUp() {
        f = new Fixture();
    }

    @Test
    @DisplayName("TC-AT-01 | AC-01 | Given a visitor, When they register with valid details, Then the account exists, has 5000.00 welcome credit and they can log in")
    void registerAndLogin() {
        User u = f.hub.users.register("Siti Aminah", "siti@example.com", "Merdeka57");
        assertEquals("5000.00", u.getWalletBalance().toPlainString());
        assertEquals(u.getId(), f.hub.users.login("siti@example.com", "Merdeka57").getId());
    }

    @Test
    @DisplayName("TC-AT-02 | AC-02 | Given a registered user, When a wrong password is entered 3 times, Then the account is locked and further logins are refused")
    void accountLockout() {
        f.hub.users.register("Siti Aminah", "siti@example.com", "Merdeka57");
        for (int i = 0; i < 3; i++) {
            assertThrows(AuthenticationException.class, () -> f.hub.users.login("siti@example.com", "nope"));
        }
        AuthenticationException locked = assertThrows(AuthenticationException.class,
                () -> f.hub.users.login("siti@example.com", "Merdeka57"));
        assertEquals("Account locked", locked.getMessage());
    }

    @Test
    @DisplayName("TC-AT-03 | AC-03 | Given an organiser, When they create 'Rock Night Live' for next week, Then it appears when a customer searches 'rock'")
    void eventAppearsInSearch() {
        f.hub.events.createEvent("Rock Night Live", "Axiata Arena", f.now().plusDays(7), 500, new BigDecimal("150.00"));
        List<Event> found = f.hub.events.search("rock");
        assertEquals(1, found.size());
        assertEquals("Rock Night Live", found.get(0).getName());
    }

    @Test
    @DisplayName("TC-AT-04 | AC-04 | Given an event that has already started, When a customer browses events, Then it is not listed")
    void pastEventsHidden() {
        f.event(Duration.ofHours(1), 100, "30.00");
        f.event(Duration.ofDays(2), 100, "30.00");
        f.clock.advance(Duration.ofHours(2));
        assertEquals(1, f.hub.events.search("").size());
    }

    @Test
    @DisplayName("TC-AT-05 | AC-05 | Given base price 150.00, When a customer buys 2 VIP tickets with code SAVE10 by card, Then they pay 567.00 and seats drop by 2")
    void bookVipWithPromo() {
        User u = f.newUser();
        Event e = f.event(Duration.ofDays(7), 500, "150.00");
        Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.VIP, 2, "SAVE10", PaymentMethod.CARD, Fixture.VALID_CARD);
        assertEquals("567.00", b.getTotal().toPlainString());
        assertEquals(498, e.getAvailable());
        assertEquals(BookingStatus.CONFIRMED, b.getStatus());
    }

    @Test
    @DisplayName("TC-AT-06 | AC-06 | Given base price 150.00, When a group buys 6 STANDARD tickets, Then the 10% group discount applies and they pay 850.50")
    void groupDiscount() {
        User u = f.newUser();
        Event e = f.event(Duration.ofDays(7), 500, "150.00");
        Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 6, "", PaymentMethod.BANK, Fixture.VALID_BANK);
        assertEquals("850.50", b.getTotal().toPlainString());
    }

    @Test
    @DisplayName("TC-AT-07 | AC-07 | Given any event, When a customer tries to buy 11 tickets in one booking, Then the booking is refused with a clear message")
    void maxTicketsPerBooking() {
        User u = f.newUser();
        Event e = f.standardEvent();
        ValidationException ex = assertThrows(ValidationException.class, () -> f.hub.bookings.book(u.getId(), e.getId(),
                TicketType.STANDARD, 11, "", PaymentMethod.WALLET, null));
        assertEquals("Quantity must be 1-10", ex.getMessage());
    }

    @Test
    @DisplayName("TC-AT-08 | AC-08 | Given an event with 2 seats all sold, When another customer tries to book 1, Then they are told there are not enough seats")
    void soldOut() {
        User a = f.newUser();
        User b = f.newUser();
        Event e = f.event(Duration.ofDays(3), 2, "40.00");
        f.hub.bookings.book(a.getId(), e.getId(), TicketType.STANDARD, 2, "", PaymentMethod.WALLET, null);
        BusinessRuleException ex = assertThrows(BusinessRuleException.class, () -> f.hub.bookings.book(b.getId(), e.getId(),
                TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null));
        assertEquals("Not enough seats available", ex.getMessage());
    }

    @Test
    @DisplayName("TC-AT-09 | AC-09 | Given an invalid card number, When a customer pays, Then no booking is created, seats are unchanged and the error is explained")
    void failedPayment() {
        User u = f.newUser();
        Event e = f.standardEvent();
        PaymentException ex = assertThrows(PaymentException.class, () -> f.hub.bookings.book(u.getId(), e.getId(),
                TicketType.STANDARD, 3, "", PaymentMethod.CARD, Fixture.BAD_LUHN_CARD));
        assertEquals("Invalid card number", ex.getMessage());
        assertEquals(1000, e.getAvailable());
        assertTrue(f.hub.bookings.forUser(u.getId()).isEmpty());
    }

    @Test
    @DisplayName("TC-AT-10 | AC-10 | Given a wallet booking for an event 5 days away, When the customer cancels, Then 100% is refunded to the wallet and seats are released")
    void fullRefund() {
        User u = f.newUser();
        Event e = f.event(Duration.ofDays(5), 100, "100.00");
        Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 2, "", PaymentMethod.WALLET, null);
        f.hub.bookings.cancel(u.getId(), b.getId());
        assertEquals("5000.00", u.getWalletBalance().toPlainString());
        assertEquals(100, e.getAvailable());
    }

    @Test
    @DisplayName("TC-AT-11 | AC-11 | Given bookings for events 30h and 10h away, When the customer cancels both, Then the 30h one refunds 50% and the 10h one is refused")
    void partialAndNoRefund() {
        User u = f.newUser();
        Event e30 = f.event(Duration.ofHours(30), 100, "100.00");
        Event e10 = f.event(Duration.ofHours(10), 100, "100.00");
        Booking b30 = f.hub.bookings.book(u.getId(), e30.getId(), TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null);
        Booking b10 = f.hub.bookings.book(u.getId(), e10.getId(), TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null);
        assertEquals("52.50", f.hub.bookings.cancel(u.getId(), b30.getId()).getRefundAmount().toPlainString());
        assertThrows(BusinessRuleException.class, () -> f.hub.bookings.cancel(u.getId(), b10.getId()));
    }

    @Test
    @DisplayName("TC-AT-12 | AC-12 | Given a customer with one active and one cancelled booking, When they view history, Then both are listed in order with correct statuses")
    void bookingHistory() {
        User u = f.newUser();
        Event e = f.standardEvent();
        Booking first = f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 1, "", PaymentMethod.WALLET, null);
        Booking second = f.hub.bookings.book(u.getId(), e.getId(), TicketType.VIP, 1, "", PaymentMethod.WALLET, null);
        f.hub.bookings.cancel(u.getId(), first.getId());
        List<Booking> history = f.hub.bookings.forUser(u.getId());
        assertEquals(2, history.size());
        assertEquals(BookingStatus.CANCELLED, history.get(0).getStatus());
        assertEquals(BookingStatus.CONFIRMED, history.get(1).getStatus());
        assertEquals(second.getId(), history.get(1).getId());
    }

    @Test
    @DisplayName("TC-AT-13 | AC-13 | Given a free event, When a customer books 4 tickets, Then the total is 0.00 and no payment details are needed")
    void freeEvent() {
        User u = f.newUser();
        Event e = f.event(Duration.ofDays(9), 1000, "0.00");
        Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 4, "", PaymentMethod.CARD, null);
        assertEquals("0.00", b.getTotal().toPlainString());
    }

    @Test
    @DisplayName("TC-AT-14 | AC-14 | Given a login failure, When the email is unknown or the password is wrong, Then the same message is shown so accounts cannot be guessed")
    void noUserEnumeration() {
        f.hub.users.register("Siti Aminah", "siti@example.com", "Merdeka57");
        String unknown = assertThrows(AuthenticationException.class, () -> f.hub.users.login("ghost@example.com", "x")).getMessage();
        String wrong = assertThrows(AuthenticationException.class, () -> f.hub.users.login("siti@example.com", "x")).getMessage();
        assertEquals(unknown, wrong);
        assertFalse(unknown.toLowerCase().contains("email"));
    }

    @Test
    @DisplayName("TC-AT-15 | AC-15 | Given a confirmed booking, When the receipt is shown, Then it states booking number, quantity, ticket type, total and status")
    void receiptContent() {
        User u = f.newUser();
        Event e = f.standardEvent();
        Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.VIP, 3, "", PaymentMethod.WALLET, null);
        String receipt = b.summary();
        assertTrue(receipt.contains("Booking #" + b.getId()));
        assertTrue(receipt.contains("3 x VIP"));
        assertTrue(receipt.contains("total 630.00"));
        assertTrue(receipt.contains("CONFIRMED"));
    }

    @Test
    @DisplayName("TC-AT-16 | AC-16 | Given a customer paying by card, When the booking is submitted, Then the confirmation is returned in under 5 seconds")
    void confirmationWithinFiveSeconds() {
        User u = f.newUser();
        Event e = f.standardEvent();
        long start = System.nanoTime();
        Booking b = f.hub.bookings.book(u.getId(), e.getId(), TicketType.STANDARD, 2, "", PaymentMethod.CARD, Fixture.VALID_CARD);
        long ms = (System.nanoTime() - start) / 1_000_000;
        PerfLog.record("TC-AT-16", "single card booking confirmation", ms + " ms (criterion: under 5000 ms)");
        assertEquals(BookingStatus.CONFIRMED, b.getStatus());
        assertTrue(ms < 5000, "took " + ms + " ms");
    }
}
