package com.tickethub.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Event {
    private final int id;
    private final String name;
    private final String venue;
    private final LocalDateTime dateTime;
    private final int capacity;
    private final BigDecimal basePrice;
    private int available;

    public Event(int id, String name, String venue, LocalDateTime dateTime, int capacity, BigDecimal basePrice) {
        this.id = id;
        this.name = name;
        this.venue = venue;
        this.dateTime = dateTime;
        this.capacity = capacity;
        this.basePrice = basePrice;
        this.available = capacity;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getVenue() { return venue; }
    public LocalDateTime getDateTime() { return dateTime; }
    public int getCapacity() { return capacity; }
    public BigDecimal getBasePrice() { return basePrice; }
    public synchronized int getAvailable() { return available; }

    /** Atomically reserves seats. Returns false (and changes nothing) if not enough remain. */
    public synchronized boolean tryReserve(int quantity) {
        if (quantity <= 0 || quantity > available) {
            return false;
        }
        available -= quantity;
        return true;
    }

    public synchronized void release(int quantity) {
        available = Math.min(capacity, available + quantity);
    }
}
