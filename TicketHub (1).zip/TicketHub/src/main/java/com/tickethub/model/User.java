package com.tickethub.model;

import java.math.BigDecimal;

public class User {
    public static final BigDecimal WELCOME_CREDIT = new BigDecimal("5000.00");
    public static final int MAX_FAILED_ATTEMPTS = 3;

    private final int id;
    private final String name;
    private final String email;
    private final String passwordHash;
    private BigDecimal walletBalance = WELCOME_CREDIT;
    private int failedAttempts;
    private boolean locked;

    public User(int id, String name, String email, String passwordHash) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPasswordHash() { return passwordHash; }
    public synchronized BigDecimal getWalletBalance() { return walletBalance; }
    public synchronized int getFailedAttempts() { return failedAttempts; }
    public synchronized boolean isLocked() { return locked; }

    public synchronized void recordFailedLogin() {
        failedAttempts++;
        if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
            locked = true;
        }
    }

    public synchronized void resetFailedLogins() {
        failedAttempts = 0;
    }

    public synchronized void unlock() {
        locked = false;
        failedAttempts = 0;
    }

    /** Returns false (and changes nothing) when the balance is insufficient. */
    public synchronized boolean debit(BigDecimal amount) {
        if (walletBalance.compareTo(amount) < 0) {
            return false;
        }
        walletBalance = walletBalance.subtract(amount);
        return true;
    }

    public synchronized void credit(BigDecimal amount) {
        walletBalance = walletBalance.add(amount);
    }
}
