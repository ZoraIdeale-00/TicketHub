package com.tickethub.model;

public enum PaymentMethod { CARD, WALLET, BANK }
