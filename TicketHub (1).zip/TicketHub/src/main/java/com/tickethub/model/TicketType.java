package com.tickethub.model;

import java.math.BigDecimal;

public enum TicketType {
    STANDARD("1.0"), VIP("2.0"), STUDENT("0.5");

    private final BigDecimal multiplier;

    TicketType(String multiplier) {
        this.multiplier = new BigDecimal(multiplier);
    }

    public BigDecimal getMultiplier() {
        return multiplier;
    }
}
