package com.tickethub.model;

public enum BookingStatus { CONFIRMED, CANCELLED }
