package com.tickethub.model;

import java.math.BigDecimal;
import java.util.Locale;

public class Booking {
    private final int id;
    private final int userId;
    private final int eventId;
    private final TicketType ticketType;
    private final int quantity;
    private final BigDecimal total;
    private final PaymentMethod paymentMethod;
    private final String transactionId;
    private BookingStatus status = BookingStatus.CONFIRMED;
    private BigDecimal refundAmount = new BigDecimal("0.00");

    public Booking(int id, int userId, int eventId, TicketType ticketType, int quantity,
                   BigDecimal total, PaymentMethod paymentMethod, String transactionId) {
        this.id = id;
        this.userId = userId;
        this.eventId = eventId;
        this.ticketType = ticketType;
        this.quantity = quantity;
        this.total = total;
        this.paymentMethod = paymentMethod;
        this.transactionId = transactionId;
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public int getEventId() { return eventId; }
    public TicketType getTicketType() { return ticketType; }
    public int getQuantity() { return quantity; }
    public BigDecimal getTotal() { return total; }
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public String getTransactionId() { return transactionId; }
    public synchronized BookingStatus getStatus() { return status; }
    public synchronized BigDecimal getRefundAmount() { return refundAmount; }

    public synchronized void markCancelled(BigDecimal refund) {
        this.status = BookingStatus.CANCELLED;
        this.refundAmount = refund;
    }

    /** Locale-independent receipt line (always uses '.' as decimal separator). */
    public String summary() {
        return String.format(Locale.ROOT, "Booking #%d | event %d | %d x %s | total %s | %s",
                id, eventId, quantity, ticketType, total.toPlainString(), getStatus());
    }
}
