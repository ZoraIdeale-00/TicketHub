package com.tickethub.model;

import com.tickethub.exception.ValidationException;
import java.math.BigDecimal;

public enum PromoCode {
    NONE("0.00"), SAVE10("0.10"), VIP20("0.20");

    private final BigDecimal discount;

    PromoCode(String discount) {
        this.discount = new BigDecimal(discount);
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    /** Blank/null means "no promo"; anything unknown is rejected. Codes are case-sensitive. */
    public static PromoCode parse(String code) {
        if (code == null || code.isBlank()) {
            return NONE;
        }
        for (PromoCode p : values()) {
            if (p != NONE && p.name().equals(code.trim())) {
                return p;
            }
        }
        throw new ValidationException("Invalid promo code");
    }
}
