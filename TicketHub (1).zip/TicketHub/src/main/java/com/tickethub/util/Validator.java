package com.tickethub.util;

import com.tickethub.exception.ValidationException;
import java.math.BigDecimal;
import java.util.regex.Pattern;

/** Central input validation rules (FR-01, FR-03, FR-05). */
public final class Validator {
    public static final int NAME_MIN = 2;
    public static final int NAME_MAX = 50;
    public static final int PASSWORD_MIN = 8;
    public static final int PASSWORD_MAX = 20;
    public static final int EMAIL_MAX = 100;
    public static final int QTY_MIN = 1;
    public static final int QTY_MAX = 10;
    public static final int CAPACITY_MIN = 1;
    public static final int CAPACITY_MAX = 10_000;
    public static final BigDecimal PRICE_MAX = new BigDecimal("10000.00");

    private static final Pattern EMAIL =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}$");

    private Validator() {
    }

    public static void name(String name) {
        if (name == null || name.trim().length() < NAME_MIN || name.trim().length() > NAME_MAX) {
            throw new ValidationException("Name must be " + NAME_MIN + "-" + NAME_MAX + " characters");
        }
    }

    public static void email(String email) {
        if (email == null || email.length() > EMAIL_MAX || !EMAIL.matcher(email.trim()).matches()) {
            throw new ValidationException("Invalid email address");
        }
    }

    public static void password(String password) {
        if (password == null || password.length() < PASSWORD_MIN || password.length() > PASSWORD_MAX) {
            throw new ValidationException("Password must be " + PASSWORD_MIN + "-" + PASSWORD_MAX + " characters");
        }
        boolean letter = false;
        boolean digit = false;
        for (char c : password.toCharArray()) {
            if (Character.isLetter(c)) {
                letter = true;
            }
            if (Character.isDigit(c)) {
                digit = true;
            }
        }
        if (!letter || !digit) {
            throw new ValidationException("Password must contain at least one letter and one digit");
        }
    }

    public static void quantity(int quantity) {
        if (quantity < QTY_MIN || quantity > QTY_MAX) {
            throw new ValidationException("Quantity must be " + QTY_MIN + "-" + QTY_MAX);
        }
    }

    public static void capacity(int capacity) {
        if (capacity < CAPACITY_MIN || capacity > CAPACITY_MAX) {
            throw new ValidationException("Capacity must be " + CAPACITY_MIN + "-" + CAPACITY_MAX);
        }
    }

    public static void price(BigDecimal price) {
        if (price == null || price.signum() < 0 || price.compareTo(PRICE_MAX) > 0) {
            throw new ValidationException("Price must be between 0 and " + PRICE_MAX);
        }
    }
}
