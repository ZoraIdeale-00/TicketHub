package com.tickethub.exception;

public class AuthenticationException extends TicketHubException {
    public AuthenticationException(String message) {
        super(message);
    }
}
