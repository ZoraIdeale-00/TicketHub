package com.tickethub.exception;

public class NotFoundException extends TicketHubException {
    public NotFoundException(String message) {
        super(message);
    }
}
