package com.tickethub.exception;

public class BusinessRuleException extends TicketHubException {
    public BusinessRuleException(String message) {
        super(message);
    }
}
