package com.tickethub.exception;

/** Base type for every expected (business) failure in TicketHub. */
public class TicketHubException extends RuntimeException {
    public TicketHubException(String message) {
        super(message);
    }
}
