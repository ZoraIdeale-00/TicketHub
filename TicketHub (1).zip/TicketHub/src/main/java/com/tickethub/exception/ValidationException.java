package com.tickethub.exception;

public class ValidationException extends TicketHubException {
    public ValidationException(String message) {
        super(message);
    }
}
