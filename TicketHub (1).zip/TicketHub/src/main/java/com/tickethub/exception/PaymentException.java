package com.tickethub.exception;

public class PaymentException extends TicketHubException {
    public PaymentException(String message) {
        super(message);
    }
}
