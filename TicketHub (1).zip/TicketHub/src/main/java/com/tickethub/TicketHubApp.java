package com.tickethub;

import com.tickethub.exception.TicketHubException;
import com.tickethub.model.Booking;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.service.TicketHubSystem;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Scanner;

/** Console front-end for TicketHub. Run this class from IntelliJ (green arrow next to main). */
public class TicketHubApp {

    public static void main(String[] args) {
        TicketHubSystem hub = new TicketHubSystem(Clock.systemDefaultZone());
        seed(hub);
        Scanner in = new Scanner(System.in);
        User current = null;
        System.out.println("=== TicketHub - Online Event Ticketing ===");
        boolean running = true;
        while (running) {
            System.out.println();
            System.out.println(current == null ? "[Guest]" : "[Logged in: " + current.getName() + "]");
            System.out.println("1) Register  2) Login  3) Browse/search events  4) Book tickets");
            System.out.println("5) My bookings  6) Cancel booking  7) Wallet balance  0) Exit");
            System.out.print("> ");
            String choice = in.hasNextLine() ? in.nextLine().trim() : "0";
            try {
                switch (choice) {
                    case "1":
                        String name = ask(in, "Name: ");
                        String email = ask(in, "Email: ");
                        String pw = ask(in, "Password (8-20 chars, letter+digit): ");
                        current = hub.users.register(name, email, pw);
                        System.out.println("Registered. Welcome wallet credit: " + current.getWalletBalance());
                        break;
                    case "2":
                        current = hub.users.login(ask(in, "Email: "), ask(in, "Password: "));
                        System.out.println("Login successful.");
                        break;
                    case "3":
                        for (Event e : hub.events.search(ask(in, "Keyword (blank = all): "))) {
                            System.out.printf(Locale.ROOT, "#%d %s @ %s on %s | base %s | seats left %d%n",
                                    e.getId(), e.getName(), e.getVenue(), e.getDateTime(),
                                    e.getBasePrice().toPlainString(), e.getAvailable());
                        }
                        break;
                    case "4":
                        requireLogin(current);
                        int eventId = Integer.parseInt(ask(in, "Event id: "));
                        TicketType type = TicketType.valueOf(ask(in, "Type (STANDARD/VIP/STUDENT): ").toUpperCase());
                        int qty = Integer.parseInt(ask(in, "Quantity (1-10): "));
                        String promo = ask(in, "Promo code (blank = none): ");
                        PaymentMethod method = PaymentMethod.valueOf(ask(in, "Payment (CARD/WALLET/BANK): ").toUpperCase());
                        String ref = method == PaymentMethod.WALLET ? "" : ask(in, "Card number / bank account: ");
                        Booking b = hub.bookings.book(current.getId(), eventId, type, qty, promo, method, ref);
                        System.out.println("Confirmed! " + b.summary() + " | txn " + b.getTransactionId());
                        break;
                    case "5":
                        requireLogin(current);
                        for (Booking x : hub.bookings.forUser(current.getId())) {
                            System.out.println(x.summary());
                        }
                        break;
                    case "6":
                        requireLogin(current);
                        Booking c = hub.bookings.cancel(current.getId(), Integer.parseInt(ask(in, "Booking id: ")));
                        System.out.println("Cancelled. Refund: " + c.getRefundAmount().toPlainString());
                        break;
                    case "7":
                        requireLogin(current);
                        System.out.println("Wallet: " + current.getWalletBalance().toPlainString());
                        break;
                    case "0":
                        running = false;
                        break;
                    default:
                        System.out.println("Unknown option.");
                }
            } catch (TicketHubException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
        }
        System.out.println("Goodbye!");
    }

    private static String ask(Scanner in, String prompt) {
        System.out.print(prompt);
        return in.hasNextLine() ? in.nextLine() : "";
    }

    private static void requireLogin(User u) {
        if (u == null) {
            throw new com.tickethub.exception.AuthenticationException("Please log in first");
        }
    }

    private static void seed(TicketHubSystem hub) {
        LocalDateTime base = LocalDateTime.now().plusDays(10);
        hub.events.createEvent("Rock Night Live", "Axiata Arena, Kuala Lumpur", base, 500, new BigDecimal("150.00"));
        hub.events.createEvent("Tech Summit 2026", "KLCC Convention Centre", base.plusDays(5), 300, new BigDecimal("80.00"));
        hub.events.createEvent("Food Fest", "Klang Valley Park", base.plusDays(20), 1000, new BigDecimal("0.00"));
    }
}
