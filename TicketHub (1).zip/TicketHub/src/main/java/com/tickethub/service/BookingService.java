package com.tickethub.service;

import com.tickethub.exception.BusinessRuleException;
import com.tickethub.exception.NotFoundException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.Booking;
import com.tickethub.model.BookingStatus;
import com.tickethub.model.Event;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.PromoCode;
import com.tickethub.model.TicketType;
import com.tickethub.model.User;
import com.tickethub.util.Validator;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** FR-05 booking and FR-08 cancellation / refund policy. */
public class BookingService {
    /** Cancellation is refused below this notice period. */
    public static final Duration NO_CANCEL_BELOW = Duration.ofHours(24);
    /** Full refund at or above this notice period; 50% between the two limits. */
    public static final Duration FULL_REFUND_FROM = Duration.ofHours(48);
    public static final BigDecimal PARTIAL_REFUND_RATE = new BigDecimal("0.50");

    private final Map<Integer, Booking> bookings = new ConcurrentHashMap<>();
    private final AtomicInteger sequence = new AtomicInteger(1);
    private final Clock clock;
    private final UserService users;
    private final EventService events;
    private final PricingService pricing;
    private final PaymentService payments;

    public BookingService(Clock clock, UserService users, EventService events,
                          PricingService pricing, PaymentService payments) {
        this.clock = clock;
        this.users = users;
        this.events = events;
        this.pricing = pricing;
        this.payments = payments;
    }

    public Booking book(int userId, int eventId, TicketType type, int quantity, String promoCode,
                        PaymentMethod method, String paymentReference) {
        Validator.quantity(quantity);
        if (type == null || method == null) {
            throw new ValidationException("Ticket type and payment method are required");
        }
        User user = users.findById(userId);
        Event event = events.findById(eventId);
        if (!event.getDateTime().isAfter(LocalDateTime.now(clock))) {
            throw new BusinessRuleException("Event has already started");
        }
        PromoCode promo = PromoCode.parse(promoCode);
        BigDecimal total = pricing.calculateTotal(event.getBasePrice(), type, quantity, promo);

        if (!event.tryReserve(quantity)) {
            throw new BusinessRuleException("Not enough seats available");
        }
        String transactionId;
        try {
            transactionId = payments.process(user, method, paymentReference, total);
        } catch (RuntimeException e) {
            event.release(quantity); // never keep seats for a failed payment
            throw e;
        }
        Booking booking = new Booking(sequence.getAndIncrement(), userId, eventId, type, quantity,
                total, method, transactionId);
        bookings.put(booking.getId(), booking);
        return booking;
    }

    public synchronized Booking cancel(int userId, int bookingId) {
        Booking booking = bookings.get(bookingId);
        if (booking == null) {
            throw new NotFoundException("Booking not found: " + bookingId);
        }
        if (booking.getUserId() != userId) {
            throw new BusinessRuleException("Booking belongs to another user");
        }
        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new BusinessRuleException("Booking already cancelled");
        }
        Event event = events.findById(booking.getEventId());
        Duration notice = Duration.between(LocalDateTime.now(clock), event.getDateTime());
        if (notice.compareTo(NO_CANCEL_BELOW) < 0) {
            throw new BusinessRuleException("Cancellation not allowed within 24 hours of the event");
        }
        BigDecimal refund = notice.compareTo(FULL_REFUND_FROM) >= 0
                ? booking.getTotal()
                : booking.getTotal().multiply(PARTIAL_REFUND_RATE).setScale(2, RoundingMode.HALF_UP);
        event.release(booking.getQuantity());
        payments.refund(users.findById(userId), booking.getPaymentMethod(), refund);
        booking.markCancelled(refund);
        return booking;
    }

    public Booking findById(int bookingId) {
        Booking b = bookings.get(bookingId);
        if (b == null) {
            throw new NotFoundException("Booking not found: " + bookingId);
        }
        return b;
    }

    public List<Booking> forUser(int userId) {
        List<Booking> list = new ArrayList<>();
        for (Booking b : bookings.values()) {
            if (b.getUserId() == userId) {
                list.add(b);
            }
        }
        list.sort((a, b) -> Integer.compare(a.getId(), b.getId()));
        return list;
    }
}
