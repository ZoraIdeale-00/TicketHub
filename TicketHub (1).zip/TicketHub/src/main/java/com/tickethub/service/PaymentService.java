package com.tickethub.service;

import com.tickethub.exception.PaymentException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.PaymentMethod;
import com.tickethub.model.User;
import com.tickethub.util.Luhn;
import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicInteger;

/** FR-07 simulated payment gateway. */
public class PaymentService {
    private final AtomicInteger txn = new AtomicInteger(1000);

    public String process(User user, PaymentMethod method, String reference, BigDecimal amount) {
        if (user == null || method == null || amount == null || amount.signum() < 0) {
            throw new ValidationException("Invalid payment request");
        }
        if (amount.signum() == 0) {
            return "FREE-" + txn.incrementAndGet();
        }
        switch (method) {
            case CARD:
                if (reference == null || !reference.matches("\\d{16}") || !Luhn.isValid(reference)) {
                    throw new PaymentException("Invalid card number");
                }
                break;
            case BANK:
                if (reference == null || !reference.matches("\\d{8,12}")) {
                    throw new PaymentException("Invalid bank account reference");
                }
                break;
            case WALLET:
                if (!user.debit(amount)) {
                    throw new PaymentException("Insufficient wallet balance");
                }
                break;
            default:
                throw new PaymentException("Unsupported payment method");
        }
        return "TXN-" + txn.incrementAndGet();
    }

    /** Wallet payments are refunded to the wallet; card/bank refunds are simulated as external. */
    public void refund(User user, PaymentMethod method, BigDecimal amount) {
        if (method == PaymentMethod.WALLET && amount.signum() > 0) {
            user.credit(amount);
        }
    }
}
