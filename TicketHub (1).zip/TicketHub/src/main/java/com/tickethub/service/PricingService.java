package com.tickethub.service;

import com.tickethub.exception.ValidationException;
import com.tickethub.model.PromoCode;
import com.tickethub.model.TicketType;
import com.tickethub.util.Validator;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * FR-06 pricing.
 * total = base x typeMultiplier x qty, then -10% when qty >= 5, then -promo, then +5% service fee,
 * rounded HALF_UP to 2 decimals only at the end.
 */
public class PricingService {
    public static final int GROUP_THRESHOLD = 5;
    public static final BigDecimal GROUP_DISCOUNT = new BigDecimal("0.10");
    public static final BigDecimal SERVICE_FEE = new BigDecimal("0.05");
    private static final BigDecimal ONE = BigDecimal.ONE;

    public BigDecimal calculateTotal(BigDecimal basePrice, TicketType type, int quantity, PromoCode promo) {
        if (basePrice == null || type == null || promo == null) {
            throw new ValidationException("Price, ticket type and promo are required");
        }
        Validator.price(basePrice);
        Validator.quantity(quantity);
        BigDecimal amount = basePrice.multiply(type.getMultiplier()).multiply(BigDecimal.valueOf(quantity));
        if (quantity >= GROUP_THRESHOLD) {
            amount = amount.multiply(ONE.subtract(GROUP_DISCOUNT));
        }
        amount = amount.multiply(ONE.subtract(promo.getDiscount()));
        amount = amount.multiply(ONE.add(SERVICE_FEE));
        return amount.setScale(2, RoundingMode.HALF_UP);
    }
}
