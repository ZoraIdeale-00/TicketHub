package com.tickethub.service;

import com.tickethub.exception.NotFoundException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.Event;
import com.tickethub.util.Validator;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** FR-03 event creation and FR-04 search. */
public class EventService {
    private final Map<Integer, Event> events = new ConcurrentHashMap<>();
    private final AtomicInteger sequence = new AtomicInteger(1);
    private final Clock clock;

    public EventService(Clock clock) {
        this.clock = clock;
    }

    public Event createEvent(String name, String venue, LocalDateTime dateTime, int capacity, BigDecimal price) {
        if (name == null || name.isBlank()) {
            throw new ValidationException("Event name is required");
        }
        if (venue == null || venue.isBlank()) {
            throw new ValidationException("Venue is required");
        }
        if (dateTime == null || !dateTime.isAfter(now())) {
            throw new ValidationException("Event date must be in the future");
        }
        Validator.capacity(capacity);
        Validator.price(price);
        Event event = new Event(sequence.getAndIncrement(), name.trim(), venue.trim(), dateTime, capacity, price);
        events.put(event.getId(), event);
        return event;
    }

    /** Upcoming events whose name or venue contains the keyword (case-insensitive). Blank = all. */
    public List<Event> search(String keyword) {
        String k = keyword == null ? "" : keyword.trim().toLowerCase();
        LocalDateTime now = now();
        List<Event> result = new ArrayList<>();
        for (Event e : events.values()) {
            boolean upcoming = e.getDateTime().isAfter(now);
            boolean match = k.isEmpty() || e.getName().toLowerCase().contains(k)
                    || e.getVenue().toLowerCase().contains(k);
            if (upcoming && match) {
                result.add(e);
            }
        }
        result.sort((a, b) -> a.getDateTime().compareTo(b.getDateTime()));
        return result;
    }

    public Event findById(int id) {
        Event e = events.get(id);
        if (e == null) {
            throw new NotFoundException("Event not found: " + id);
        }
        return e;
    }

    public LocalDateTime now() {
        return LocalDateTime.now(clock);
    }
}
