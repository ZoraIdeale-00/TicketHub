package com.tickethub.service;

import java.time.Clock;

/** Wires all services together. Tests build it with a controllable Clock. */
public class TicketHubSystem {
    public final UserService users = new UserService();
    public final PricingService pricing = new PricingService();
    public final PaymentService payments = new PaymentService();
    public final EventService events;
    public final BookingService bookings;

    public TicketHubSystem(Clock clock) {
        this.events = new EventService(clock);
        this.bookings = new BookingService(clock, users, events, pricing, payments);
    }
}
