package com.tickethub.service;

import com.tickethub.exception.AuthenticationException;
import com.tickethub.exception.BusinessRuleException;
import com.tickethub.exception.NotFoundException;
import com.tickethub.exception.ValidationException;
import com.tickethub.model.User;
import com.tickethub.util.Validator;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** FR-01 registration and FR-02 login / lock-out. */
public class UserService {
    private final Map<String, User> byEmail = new ConcurrentHashMap<>();
    private final Map<Integer, User> byId = new ConcurrentHashMap<>();
    private final AtomicInteger sequence = new AtomicInteger(1);

    public synchronized User register(String name, String email, String password) {
        Validator.name(name);
        Validator.email(email);
        Validator.password(password);
        String key = email.trim().toLowerCase();
        if (byEmail.containsKey(key)) {
            throw new BusinessRuleException("Email already registered");
        }
        User user = new User(sequence.getAndIncrement(), name.trim(), key, hash(password));
        byEmail.put(key, user);
        byId.put(user.getId(), user);
        return user;
    }

    public User login(String email, String password) {
        if (email == null || password == null) {
            throw new AuthenticationException("Invalid credentials");
        }
        User user = byEmail.get(email.trim().toLowerCase());
        if (user == null) {
            throw new AuthenticationException("Invalid credentials");
        }
        synchronized (user) {
            if (user.isLocked()) {
                throw new AuthenticationException("Account locked");
            }
            if (!user.getPasswordHash().equals(hash(password))) {
                user.recordFailedLogin();
                throw new AuthenticationException(user.isLocked() ? "Account locked" : "Invalid credentials");
            }
            user.resetFailedLogins();
            return user;
        }
    }

    public User findById(int id) {
        User user = byId.get(id);
        if (user == null) {
            throw new NotFoundException("User not found: " + id);
        }
        return user;
    }

    public int count() {
        return byId.size();
    }

    private static String hash(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(password.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new ValidationException("Hashing unavailable");
        }
    }
}
