# TicketHub – Online Event Ticketing System

A console-based, in-memory event-ticketing system written in Java 17+ with a complete
**functional / system / acceptance** test suite (JUnit 5) and the matching assignment documents.

## Open in IntelliJ IDEA Community
1. Unzip `TicketHub.zip`.
2. **File ▸ Open…** and select the `TicketHub` folder (or its `pom.xml`) ▸ *Open as Project* ▸ *Trust Project*.
3. Wait for Maven to import (first time it downloads JUnit 5 and the JaCoCo plugin – internet needed once).
4. Set the Project SDK to any JDK 17 or newer (**File ▸ Project Structure ▸ Project**).

## Run the application
Open `src/main/java/com/tickethub/TicketHubApp.java` and click the green ▶ next to `main`.
Three demo events are pre-loaded. New users get a 5000.00 wallet credit.

## Run the tests
* Whole suite: right-click `src/test/java` ▸ **Run 'All Tests'**, or open the Maven tool window ▸ *Lifecycle* ▸ **test**.
* One stage: right-click the `functional`, `system` or `acceptance` package ▸ Run.
* Command line (if Maven is installed): `mvn test`
* Coverage: after `mvn test` open `target/site/jacoco/index.html` (or use IntelliJ ▸ *Run with Coverage*).

Expected result: **141 tests, 0 failures** (101 functional, 24 system, 16 acceptance).

## Project layout
```
src/main/java/com/tickethub
  model/      User, Event, Booking, enums (TicketType, PromoCode, PaymentMethod, BookingStatus)
  service/    UserService, EventService, PricingService, PaymentService, BookingService, TicketHubSystem
  util/       Validator, Luhn
  exception/  TicketHubException + ValidationException, NotFound…, BusinessRule…, Payment…, Authentication…
  TicketHubApp.java   console menu
src/test/java/com/tickethub
  functional/  EP, BVA, pairwise, error-guessing and random tests (TC-EP/BVA/PW/EG/RND-nn)
  system/      robustness, performance, scalability, interoperability (TC-SYS-xxx-nn)
  acceptance/  Given/When/Then scenarios AC-01 … AC-16 (TC-AT-nn)
  support/     Fixture, MutableClock (controllable time), PerfLog
docs/
  TicketHub_Test_Report.docx      full test report (all four assignment parts)
  TicketHub_Presentation.pptx     slide deck
  diagrams/                       process diagram and charts (PNG)
```

## Business rules (the requirements under test)
| ID | Rule |
|----|------|
| FR-01 | Register: name 2–50 chars, valid unique e-mail, password 8–20 chars with a letter and a digit |
| FR-02 | Login; account locks after 3 consecutive failures |
| FR-03 | Create event: future date, capacity 1–10 000, price 0.00–10 000.00 |
| FR-04 | Search upcoming events by keyword (name or venue, case-insensitive) |
| FR-05 | Book 1–10 tickets, never more than the seats left |
| FR-06 | Price = base × type (STANDARD 1.0, VIP 2.0, STUDENT 0.5) × qty; −10 % if qty ≥ 5; promo SAVE10 −10 % / VIP20 −20 %; +5 % service fee; round half-up to 2 dp |
| FR-07 | Pay by CARD (16 digits, Luhn), BANK (8–12 digits) or WALLET (sufficient balance) |
| FR-08 | Cancel: ≥ 48 h before = 100 % refund, 24–48 h = 50 %, < 24 h = refused |
